public class Segment {
    private int row;
    private int col;

    //Contructor 
    public Segment(int row, int col){
        this.row = row;
        this.col = col;
    }

    public int getRow(){
        return row;
    }

    public int getCol(){
        return col;
    }

    public void setRow(int row){
        this.row = row;
    }

    public void setCol(int col){
        this.col = col;
    }

    public String toString() {
        return "Row: " + getRow() + ", Column: " + getCol();
    }
}