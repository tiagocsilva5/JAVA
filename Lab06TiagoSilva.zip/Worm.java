public class Worm {
    private LinkedList segments;
    private String color;

    // Constructor
    public Worm(String color) {
        this.segments = new LinkedList();
        this.color = color;
        initializeWorm();
    }

    private void initializeWorm() {
        int i;
        for (i = 0; i < 6; i++) {
            segments.add(new Segment(10 + i, 10));
        }
    }

    // Add a segment to the end of the worm
    public void addSegment() {
        LNode lastNode;
        Segment segment;
        
        lastNode = segments.getLastNode();
        segment = lastNode.getData();
        segments.add(segment);
    }

    // Remove the first segment of the worm
    public void removeSegment() {
        segments.remove();
    }

    // Display the worm
    public void display() {
        System.out.println("Worm color: " + color);
        System.out.println("Segments:");
        segments.display();
    }

    public void moveRight() {
        LNode headNode;
        Segment headSegment;
        headNode = segments.getHead();
        
        if (headNode != null) {
            headSegment = headNode.getData();
            headSegment.setCol(headSegment.getCol() + 1);
        }
    }

    public void moveLeft() {
        LNode headNode;
        Segment headSegment;
        headNode = segments.getHead();

        if (headNode != null) {
            headSegment = headNode.getData();
            headSegment.setCol(headSegment.getCol() - 1);
        }
    }
    
    public void moveDown() {
        LNode headNode;
        Segment headSegment;
        headNode = segments.getHead();
        
        if (headNode != null) {
            headSegment = headNode.getData();
            headSegment.setRow(headSegment.getRow() - 1);
        }
    }
    public void moveUp() {
        LNode headNode;
        Segment headSegment;
        headNode = segments.getHead();
        
        if (headNode != null) {
            headSegment = headNode.getData();
            headSegment.setRow(headSegment.getRow() + 1);
        }
    }
}
