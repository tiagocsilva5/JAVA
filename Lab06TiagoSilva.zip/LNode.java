public class LNode {
    private Segment data;
    private LNode next;
    
    //Constructor
    public LNode(Segment data) {
        this.data = data;
        this.next = null;
    }
    
    public Segment getData() { 
        return data; 
    }
    
    public LNode getNext() { 
        return next; 
    }
    
    public void setNext(LNode next) {
        this.next = next; 
    }

    public void setData(Segment data) {
        this.data = data;
    }
}    

        
    