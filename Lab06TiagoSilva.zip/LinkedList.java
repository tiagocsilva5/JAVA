public class LinkedList {
    private LNode head;
    private LNode tail;

    // Constructor
    public LinkedList() {
        this.head = null;
        this.tail = null;
    }

    public LNode getHead() {
        return head;
    }

    public LNode getLastNode() {
        LNode current, lastNode;

        current = head;
        lastNode = null;
        while (current != null) {
            lastNode = current;
            current = current.getNext();
        }

        return lastNode;
    }

    public int getSize() {
        int counter;
        LNode current;

        current = head;
        counter = 0;
        while (current != null) {
            counter++;
            current = current.getNext();
        }
        return counter;
    }
    
    // Add a Segment object to the end of the linked list
    public void add(Segment data) {
        LNode newNode = new LNode(data);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.setNext(newNode);
            tail = newNode;
        }
    }

    // Remove data from the beginning of the linked list
    public void remove() {
        if (head != null) {
            head = head.getNext();
            if (head == null) {
                tail = null;
            }
        }
    }

    public void display() {
        LNode current = head;
        while (current != null) {
            System.out.println("Data: " + current.getData().toString());
            current = current.getNext();
        }
    }
}