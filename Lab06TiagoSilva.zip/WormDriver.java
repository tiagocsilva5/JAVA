import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.Scanner;

import java.io.FileReader;


public class WormDriver {
    public static void main(String[] args) throws IOException {
        Scanner keyboard;
        Scanner file;
        Worm worm;
        String color; 
        String input;

        file = new Scanner(new FileReader(args[0]));
        keyboard = new Scanner(System.in);

        System.out.print("What's the color of the worm? : ");
        color = keyboard.nextLine();
        worm = new Worm(color);

        while (file.hasNext()) {
            try {
                input = file.nextLine();
                while (input != "q") {
                    switch (input) {
                        case "q":
                            System.out.println("Game Over");
                            break;
                        case "h":
                            worm.moveLeft();
                            break;
                        case "j":
                            worm.moveDown();
                            break;
                        case "k":
                            worm.moveUp();
                            break;
                        case "l":
                            worm.moveRight();
                            break;
                        case "+":
                            worm.addSegment();
                            break;
                        case "-":
                            worm.removeSegment();
                            break;
                        case "=":
                            worm.display();
                            break;
                        
                        default:
                            System.out.println("Invalid input");
                            break;
                    }
                    input = file.nextLine();
                }
            } catch (NoSuchElementException elementException) {
                break;
            }
        }
        keyboard.close();
    }
}
