/****************************************************
 * Author:      Dr. Cathy Bareiss
 * Modifier:    Tiago Silva
 * Course:      CSC 121
 * Assignment:  Fifth Lab Program
*****************************************************/
import java.io.*;
import java.util.*;

public class DisplayMonthMethod{
    public static void main(String[] args){
    
        // DECLARATIONS 
        Scanner keyboard;  
        int year;
        int month;
        int startday;
        
        
        //input 
        keyboard = new Scanner(System.in); 
        
        System.out.println("Input the year, followed by the month," +
                           " and the day it starts on " + 
                           "(with Sunday being 0 and Saturday being 6)." +  
                           " The year can range from 1500 to 5000.");
        year = getValid( 1500, 5000, "Out of range", keyboard); 
        month = getValid( 1, 12, "Out of range", keyboard);
        startday = getValid( 0, 6, "Out of range", keyboard);
        displayMonth( year, month, startday);   
        
    }
    
    public static int getValid(int low, int high, String message, Scanner keyboard) {
        int value;
            value = keyboard.nextInt();
        while (value > high || value < low) {
            System.out.println(message);
            value = keyboard.nextInt();
       }
           
    return value; 
    
    }
    
    public static void displayMonth(int year, int month, int startday) {
        int numDays;
        int i;
        int sum;
        boolean greaterThanNumDays;
        greaterThanNumDays = false; 
        sum = 7 - startday; 
        numDays = getNumDays(year, month);
        displayMonthTitle(month);
        displaySpaces(startday);
        startday = 1;
        while (greaterThanNumDays == false){
            if (sum > numDays) {
               greaterThanNumDays = true;
               sum = numDays;
            }
        
            displayWeek(startday, sum);
            startday = sum + 1; 
            sum += 7;
        }
    }
    
    public static int getNumDays(int year, int month) {
         int numDays;
         numDays = 0;
         switch(month){
             case 1: numDays = 31; break;
             case 2: if (year%4 != 0) numDays = 28;
                     else if (year%100 == 0 && year%400 != 0) numDays = 28;
                     else numDays = 29;
                     break;
             case 3: numDays = 31; break;
             case 4: numDays = 30; break;
             case 5: numDays = 31; break;
             case 6: numDays = 30; break;
             case 7: numDays = 31; break;
             case 8: numDays = 31; break;
             case 9: numDays = 30; break;
             case 10: numDays = 31; break;
             case 11: numDays = 30; break;
             case 12: numDays = 31; break;
         }
         
       return numDays;
    }
    
    
    public static void displayMonthTitle(int month) {
         switch(month){
            case 1: System.out.println("Janeiro"); break;
            case 2: System.out.println("Fevereiro"); break;
            case 3: System.out.println("Marco");; break;
            case 4: System.out.println("Abril");; break;
            case 5: System.out.println("Maio"); break;
            case 6: System.out.println("Junho"); break;
            case 7: System.out.println("Julho"); break;
            case 8: System.out.println("Agosto"); break;
            case 9: System.out.println("Setembro"); break;
            case 10: System.out.println("Outubro"); break;
            case 11: System.out.println("Novembro"); break;
            case 12: System.out.println("Dezembro"); break;
         }   
    
    }
    
    public static void displaySpaces(int n) {
        int i;
        
        for (i=0; i <= 3*n; i++)
            System.out.print(" ");        
        
    }
    
    public static void displayWeek(int low, int high) {
        int curDay;
        for (curDay = low; curDay <= high; curDay++) {
            if (curDay < 10 && curDay != 1)
            System.out.print(" "+curDay+" ");
            else System.out.print(curDay+ " ");
            if (curDay == high) {
               System.out.println(" ");
        
            }
    
        }
   } 
    
}