/******************************************************
 * Author:      Dr. Cathy Bareiss
 * Modifier:    Tiago Silva
 * Course:      CSC 121
 * Assignment:  Twelfth Inventory
*******************************************************/
import java.util.*;
import java.io.*;

public class Inventory{
    // field variables 
    public static final int MAXITEMS = 100;
    private Item[] items;
    private int itemCount;
    
    //constructors
    public Inventory() {
        items = new Item[MAXITEMS];
        itemCount = 0;
    }
    
    // accessors
    public int length() {
        return itemCount;
    }
    
    public Item getItem(int index) {
        if (index >= 0 && index < itemCount) {
            return items[index];
        } 
        else return null; 
        }
    
    public Item getItem(String name) {
        boolean found;
        int location;
        
        found = false;
        location = 0;
        while (items[location] != null && location <= itemCount && !found) {
            if (items[location].equalsName(name))
                found = true;
            else
                location++;
        }        
        if (found) return items[location];
        return new Item("No item", -1, -1);
        
    }
    
    // mutators
    
    public void addItem(Item newItems) {
        if (itemCount < items.length -1 ) {
            items[itemCount] = newItems;
            itemCount++;
        }
    }
    
    // Removes an item 
    public void removeItem(String itemName) {
        int index;
        int i;
        index = lookup(itemName);
        if (index != -1) {
            for (i = index; i < itemCount - 1; i++) {
                items[i] = items[i + 1];
            }
            items[itemCount - 1] = null;
            itemCount--;
        } 
        else {
            System.out.println("Item is not in the inventory.");
        }
    }
    
    // Sorts the list based on the compareTo operator of the item
    public void sort(){
        Item temp;
        int j;
        int counter;
        counter = 0;
        for (int i = 1; i < itemCount; i++) {
            temp = items[i];
            j= i - 1;
            while (j >= 0 && items[j].compareTo(temp) == 1) {
                items[j + 1] = items[j];
                j= j - 1;
            }
            items[j + 1] = temp;
        }
    }    
    // helpers
    // Dr. Bareiss's code
    public static int[] loadInt(String filename) {
        int i;
        int[] data;
        Scanner file;
        data = new int[MAXITEMS];
        i = 0;
        
        try {
            file = new Scanner(new FileReader(filename));
            while (file.hasNext()) {
                data[i] = file.nextInt();
                i++;
            }
        file.close();
        } 
        catch (IOException e) {
            System.err.println("Problems loading "+filename);
            System.exit(-1);
        }

        return data;
    }

    // Loads items 
    public void loadItems(String stockName, 
                          String reoderName, String namesName) {
        int i;
        int size;
        int[] stock;
        int[] reorder;
        size = MAXITEMS;
        String[] names;
        
        stock = loadInt("inStock.txt");
        reorder = loadInt("reorder.txt");
        names = loadString("names.txt");
        
        for (i = 0; i <= size - 1; i++) {
            items[i] = new Item(names[i], stock[i], reorder[i]);
        }
    }
    
    // Dr. Bareiss's code
    public static String[] loadString(String filename) {
        int i;
        String[] data;
        Scanner file;
        
        data = new String[MAXITEMS];
        i = 0;
        try {
            file = new Scanner(new FileReader(filename));
            while (file.hasNext()) {
                data[i] = file.nextLine();
                i++;
            }
        file.close();
        } catch (IOException e) {
            System.err.println("Problems loading "+filename);
            System.exit(-1);
        }

        return data;
    }

    
    // Saves items
    public void saveItems() {
        PrintStream file;
        int i;
        int size;
        size = MAXITEMS;
        try {
            file = new PrintStream("yourInventory.txt");
        } catch (IOException e) {
            System.err.println("Problems creating yourInventory.txt");
            return;
        }
        for (i = 0; i <= size - 1; i++) 
            file.println(items[i]);
        file.close();
    }

    // returns the location of an Item based on its name
    private int lookup(String itemName) {
        int i;
        for (i = 0; i < itemCount; i++) {
            if (items[i].getName().equals(itemName)) {
                return i;
            }
        }
        return -1; 
    }

    // returns the location of an Item
    private int lookup(Item item) {
        int i;
        for (i = 0; i < itemCount; i++) {
            if (items[i].equalsItem(item)) {
                return i;
            }
        }
        return -1; 
    }

        
    public String toString() {
        int i;
        String result;
        
        result = "";
        for (i = 0; i < itemCount; i++) 
            result += items[i].toString()+"\n";
        return result;
    }
} 
 