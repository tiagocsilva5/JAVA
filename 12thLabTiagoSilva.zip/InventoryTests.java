/******************************************************
 * Author:      Dr. Cathy Bareiss
 * Modifier:
 * Course:      CSC 121
 * Assignment:  Create Inventory and Item classes
 * File:        A test driver for Inventory
*******************************************************/
public class InventoryTests {
    public static void main(String[] args) {
        testZero();
        testOne();
        testTwo();
        testThree();
        testFour();
        testFive();
    }
    
    // This method tests:
    //      both constructors
    //      simple add
    //      length
    //      both getItems (simply)
    //      toString
    public static void testZero() {
        Inventory invt;
        System.out.println("*************");
        System.out.println("TEST ZERO");
        invt = new Inventory();
        addItem(invt,"a",1,1);
        System.out.println(invt.toString());
        System.out.println(invt.length());
        System.out.println(invt.getItem("a").toString());
        System.out.println(invt.getItem(0).toString());
        System.out.println("*************");
    }
    
    // The method test:
    //      loading inventory from a file
    //      sort
    public static void testOne() {
        Inventory invt;
        System.out.println("*************");
        System.out.println("TEST ONE");
        invt = new Inventory();
        invt.loadItems("names.txt", "inStock.txt", "reorder.txt");
        System.out.println(invt.toString());
        System.out.println(invt.toString());
        System.out.println("*************");
    }
    
    // This method tests:
    //      access all items both ways
    //      accessing missing items both ways
    public static void testTwo() {
        Inventory invt;
        System.out.println("*************");
        System.out.println("TEST TWO");
        invt = new Inventory();
        addFour(invt);
        for (int i=0; i < invt.length(); i++)
            System.out.println(invt.getItem(i).toString());
        for (char c='A'; c <= 'D'; c++)
            System.out.println(invt.getItem(c+"").toString());
        if (invt.getItem("missing") == null) System.out.println("Null");
        if (invt.getItem(5) == null) System.out.println("Null");
        System.out.println("*************");
    }
    
    // This method tests removing an item
    public static void testThree() {
        Inventory invt;
        invt = new Inventory();
        System.out.println("*************");
        System.out.println("TEST THREE");
        addFour(invt);
        System.out.println(invt.toString());
        invt.removeItem("C");
        System.out.println(invt.toString());
        System.out.println("*************");
    }
    
    // This method tests sorting
    public static void testFour() {
        Inventory invt;
        System.out.println("*************");
        System.out.println("TEST FOUR");
        invt = new Inventory();
        addFour(invt);
        System.out.println(invt.toString());
        invt.sort();
        System.out.println(invt.toString());
        System.out.println("*************");
    }
    
    // This methods tests reading from a file and writing to a file
    public static void testFive() {
        Inventory invt;
        System.out.println("*************");
        System.out.println("TEST FIVE");
        invt = new Inventory();
        invt.loadItems("names.txt", "inStock.txt", "reorder.txt");
        invt.sort();
        invt.saveItems();
        System.out.println("*************");
    }
    
    // to automate adding one item
    public static void addItem(Inventory invt, String name, int inventory,
                               int reorder) {
        Item temp;
        temp = new Item(name, inventory, reorder);
        invt.addItem(temp);
    }
    
    // to automate adding four specific items
    public static void addFour(Inventory invt) {
        Item temp;
        
        addItem(invt,"B",5,6);
        addItem(invt,"D",3, 2);
        addItem(invt,"A",8,10);
        addItem(invt,"C",4,4);
    }
}