/******************************************************
 * Author:      Dr. Cathy Bareiss
 * Modifier:    Tiago Silva
 * Course:      CSC 121
 * Assignment:  Twelfth Lab Test 
*******************************************************/
public class ItemTests {
    public static void main(String[] args) {
        Item i1, i2, i3;
    
        i1 = new Item("Beanie", 3, 3);
        i2 = new Item ("Gloves", 8, 5);
        System.out.println("Name: "+i2.getName()+" In stock: "+i2.getAmount()+
                           " Min. Amount: "+i2.getReorder());
        i1.setAmount(3);
        i1.setReorder(3);
        i3 = new Item("Kit Kat", 2, i1.getReorder() + 1);
        System.out.println(i1.toString());
        System.out.println(i2.toString());
        System.out.println(i3.toString());
    }
}   
