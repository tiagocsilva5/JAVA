/******************************************************
 * Author:      Dr. Cathy Bareiss
 * Modifier:    Tiago Silva
 * Course:      CSC 121
 * Assignment:  Twelfth Lab Inventory using classes
*******************************************************/
import java.util.*;
import java.io.*;

public class Item{
    // field variables
    private String name;
    private int instockLevel;
    private int reorderAmount;
    
    // constructors -> goal:  to initialize all field variables
    public Item() {
        name="";
        instockLevel = 0;
        reorderAmount = 0;
    }
    
    public Item (String name, int instockLevel, int reorderAmount) {
        this.name = name;
        this.instockLevel = instockLevel;
        this.reorderAmount = reorderAmount;
    }
    
    public String getName() {
        return name;
    }
    
    public int getAmount() {
        return instockLevel;
    }
    
    public int getReorder() {
        return reorderAmount;
    }
    
    // mutators
    public void setName(String inName) {
        name = inName;
    }
    
    public void setAmount(int inAmount) {
        instockLevel = inAmount;
    }
    
    public void setReorder(int inReorder) {
        reorderAmount = inReorder;
    }
    
    public void updateAmount(int increment) {
        instockLevel += increment;
    }
    
    // helper methods    
    
    public boolean equalsName(String newName ) { // ask prof about string
        if (name == newName)
            return true;
        else
            return false;
    }
    
    public boolean equalsItem(Item newItem ) { // ask prof about string
        if (name == newItem.getName())
            return true;
        else
            return false;
    }
    
    public int compareTo(Item newItem) {
        if (name.compareTo(newItem.getName()) < 0) return -1;
        if (name.compareTo(newItem.getName()) > 0) return 1;
        return 0;
    }

    public String toString() {
        return "Name: "+name+"\t In Stock: "+instockLevel+
               "\t Reorder Amount: "+reorderAmount;
    }
}