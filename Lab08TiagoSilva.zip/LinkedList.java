/*************************************************
 /** Author:   Tiago Silva
 /*  Course:   CSC 221, Spring 2024
 /*  Lab:      Lab 8 - Final Project: Worm Game
 /*  File:     LinkedList
 *************************************************/
public class LinkedList {
    private LNode head;

    public LinkedList() {
        this.head = null;
    }

    public void addEnd(Segment segment) {
        LNode newNode = new LNode(segment);
        if (head == null) {
            head = newNode;
            return;
        }

        LNode lastNode = head;
        while (lastNode.getNext() != null) {
            lastNode = lastNode.getNext();
        }
        lastNode.setNext(newNode);
    }

    // Method to get the head of the linked list
    public LNode getHead() {
        return head;
    }

    // Method to get the tail of the linked list
    public LNode getTail() {
        if (head == null || head.getNext() == null) {
            return head;
        }
        LNode current = head;
        while (current.getNext() != null) {
            current = current.getNext();
        }
        return current;
    }

    public void addHead(int row, int col) {
        LNode current;
        int i;
        current = new LNode(new Segment(row, col));
        current.setNext(head);
        head = current;
    }

    public void deleteTail(){
        LNode current = head;
        while (current.getNext().getNext() != null) {
            current = current.getNext();
        }
        current.setNext(null);
    }
}