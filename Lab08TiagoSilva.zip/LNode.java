/*************************************************
 /** Author:   Tiago Silva
 /*  Course:   CSC 221, Spring 2024
 /*  Lab:      Lab 8 - Final Project: Worm Game
 /*  File:     LNode
 *************************************************/
public class LNode {
    Segment segment;
    LNode next;

    public LNode() {
        segment = null;
        next = null;
    }

    public LNode(Segment segment) {
        this.segment = segment;
        next = null;
    }

    public LNode getNext() {
        return next;
    }

    public void setNext(LNode next) {
        this.next = next;
    }

    public Segment getSegment() {
        return segment;
    }
}

