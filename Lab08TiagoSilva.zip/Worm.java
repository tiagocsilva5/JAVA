/*************************************************
 /** Author:   Tiago Silva
 /*  Course:   CSC 221, Spring 2024
 /*  Lab:      Lab 8 - Final Project: Worm Game
 /*  File:     Worm
 *************************************************/
public class Worm {
    private LinkedList worm;
    private String color;


    // Constructor
    public Worm(int colorNum) {
        worm = new LinkedList();
        switch(colorNum) {
            case 0:
                color = "Red";
                for (int i = 0; i < 5; i++) {
                    worm.addEnd(new Segment(0, i));
        }
                break;
            case 1:
                color = "Black";
                for (int i = 29; i > 23; i--) {
                    worm.addEnd(new Segment(29, i));
                }
                break;
        }

    }

    // Check if a move is possible
    private boolean movePossible(int row, int column, int min, int max) {
        if (row < min || row >= max || column < min || column >= max) {
            return false;
        }

        LNode cur = worm.getHead();
        while (cur != null) {
            if (cur.getSegment().getRow() == row
                    && cur.getSegment().getCol() == column) {
                return false;
            }
            cur = cur.getNext();
        }

        return true;
    }

    private boolean hitWorm(int row, int column, Worm other) {
        LNode otherCur = other.getWormHead();
        while (otherCur != null) {
            if (otherCur.getSegment().getRow() == row
                    && otherCur.getSegment().getCol() == column) {
                return true;
            }
            otherCur = otherCur.getNext();
        }
        return false;
    }

    public int[] move(char dir, int min, int max, Worm other) {
        int row = 0;
        int column = 0;
        int[] tail;

        tail = new int[] { worm.getTail().getSegment().getRow(),
                worm.getTail().getSegment().getCol() };

        switch (dir) {
            // Left
            case 'l':
                row = worm.getHead().getSegment().getRow();
                column = worm.getHead().getSegment().getCol() - 1;
                break;
            // Right
            case 'r':
                row = worm.getHead().getSegment().getRow();
                column = worm.getHead().getSegment().getCol() + 1;
                break;
            // Up
            case 'u':
                row = worm.getHead().getSegment().getRow() - 1;
                column = worm.getHead().getSegment().getCol();
                break;
            // Down
            case 'd':
                row = worm.getHead().getSegment().getRow() + 1;
                column = worm.getHead().getSegment().getCol();
                break;
        }

        if (movePossible(row, column, min, max)) {
            if (hitWorm(row, column, other)) {
                System.out.println("You hit the worm!");
                this.color = "";
                tail = new int[] { -2 };
            } else {
                worm.addHead(row, column);
                worm.deleteTail();
            }
        } else {
            tail = new int[] { -1 };
        }
        return tail;
    }

    public LNode getWormHead() {
        return worm.getHead();
    }

    public LinkedList getNumSegments() {
        return worm;
    }

    // Get the color of the worm
    public String getColor() {
        return color;
    }

    public void plusWorm(){
        worm.addHead(getWormHead().getSegment().getRow(),
                getWormHead().getSegment().getCol());
    }

    public void minusWorm(){
        worm.deleteTail();
    }

    // Print out the worm
    public String toString() {
        return color + "\n" + worm.toString();
    }
}
