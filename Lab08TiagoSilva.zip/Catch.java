/*************************************************
 /** Author:   Tiago Silva
 /*  Course:   CSC 221, Spring 2024
 /*  Lab:      Lab 8 - Final Project: Worm Game
 /*  File:     Catch
 *************************************************/
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Catch extends Frame {
    protected JFrame myFrame;
    protected Container myPane;
    protected WormActionListener listener;
    protected JLabel[][] squares;
    protected Worm blackWorm, redWorm;
    protected JPanel winnerPanel;
    protected JLabel winnerLabel;
    protected JButton restartButton;
    protected JLabel plusSign, minusSign;
    int random1, random2, random3, random4;
    protected boolean gameOver;
    int i;
    boolean[][] usedTiles = new boolean[30][30];

    public Catch() {
        myFrame = new JFrame();
        redWorm = new Worm(0);
        blackWorm = new Worm(1);
        squares = new JLabel[30][30];
        gameOver = false;
        random1 = getRandomNumber();
        random2 = getRandomNumber();
        random3 = getRandomNumber();
        random4 = getRandomNumber();

        myFrame.addKeyListener(new MyKey());

        setGraphics();
    }

    public class WormActionListener implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            new Catch();
        }
    }

    public void setGraphics() {
        JPanel gamePanel, winnerPanel;
        JLabel boardSquare;
        LNode currNode;
        Segment segment;

        myPane = myFrame.getContentPane();
        gamePanel = new JPanel();
        winnerPanel = new JPanel();
        listener = new WormActionListener();

        gamePanel.setLayout(new GridLayout(30, 30));
        gamePanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));

        winnerPanel.setLayout(new GridLayout(30, 30));
        winnerPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));

        boardSquare = new JLabel();
        boardSquare.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        boardSquare.setPreferredSize(new Dimension(40, 25));

        // set random tiles for adding and removing segments of worm
        plusSign = new JLabel();
        minusSign = new JLabel();

        for (i = 0; i < 10; i++) {
            squares[random1][random2] = plusSign;
            squares[random3][random4] = minusSign;
        }

        for (int i = 0; i < 30; i++) {
            for (int j = 0; j < 30; j++) {
                if (squares[i][j] == null) {
                    squares[i][j] = new JLabel();
                }
                squares[i][j].setBorder(
                        BorderFactory.createLineBorder(Color.LIGHT_GRAY));
                squares[i][j].setPreferredSize(
                        new Dimension(40, 30));

            }
        }

        currNode = redWorm.getNumSegments().getHead();
        segment = currNode.getSegment();
        for (i = 0; i < 5; i++){
            squares[segment.getRow()]
                    [segment.getCol()].setBackground(Color.RED);
            squares[segment.getRow()][segment.getCol()].setOpaque(true);
            currNode = currNode.getNext();
            if (currNode != null)
                segment = currNode.getSegment();
            if (squares[segment.getRow()][segment.getCol()] == plusSign
                    && !usedTiles[segment.getRow()][segment.getCol()]) {
                redWorm.plusWorm();
                squares[segment.getRow()][segment.getCol()].setText("");
                usedTiles[segment.getRow()][segment.getCol()] = true;
            } else if (squares[segment.getRow()][segment.getCol()] == minusSign
                    && !usedTiles[segment.getRow()][segment.getCol()]) {
                redWorm.minusWorm();
                squares[segment.getRow()][segment.getCol()].setText("");
                usedTiles[segment.getRow()][segment.getCol()] = true;
            }
        }

        currNode = blackWorm.getNumSegments().getHead();
        segment = currNode.getSegment();
         for (i = 0; i < 5; i++) {
             squares[segment.getRow()]
                     [segment.getCol()].setBackground(Color.BLACK);
             squares[segment.getRow()][segment.getCol()].setOpaque(true);
             currNode = currNode.getNext();
             if(currNode != null)
                 segment = currNode.getSegment();
        }

        for (int i = 0; i < 30; i++)
            for (int j = 0; j < 30; j++)
                gamePanel.add(squares[i][j]);


        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFrame.setTitle("Catch");
        myFrame.setSize(600, 600);
        myFrame.setVisible(true);

        if (redWorm.getColor().equals("")) {
            winnerLabel = new JLabel("Black Worm is the Winner!",
                                        SwingConstants.CENTER);
            restartButton= new JButton("Restart Game");
            restartButton.addActionListener(listener);
            winnerPanel.add(winnerLabel);
            winnerPanel.add(restartButton);
            myPane.add(winnerPanel);
        } else if (blackWorm.getColor().equals("")) {
            winnerLabel = new JLabel("Red Worm is the Winner!",
                                        SwingConstants.CENTER);
            restartButton= new JButton("Restart Game");
            restartButton.addActionListener(listener);
            winnerPanel.add(winnerLabel);
            winnerPanel.add(restartButton);
            myPane.add(winnerPanel);
        } else myPane.add(gamePanel);

    }
    private void updateGrid() {
        LNode currNode;
        Segment segment;
        currNode = redWorm.getNumSegments().getHead();
        segment = currNode.getSegment();

        for (i = 0; i < 5; i++){
            squares[segment.getRow()]
                    [segment.getCol()].setBackground(Color.RED);
            squares[segment.getRow()][segment.getCol()].setOpaque(true);
            currNode = currNode.getNext();
            if(currNode != null)
                segment = currNode.getSegment();
        }

        currNode = blackWorm.getNumSegments().getHead();
        segment = currNode.getSegment();

        for (i = 0; i < 5; i++) {
            squares[segment.getRow()]
                    [segment.getCol()].setBackground(Color.BLACK);
            squares[segment.getRow()][segment.getCol()].setOpaque(true);
            currNode = currNode.getNext();
            if(currNode != null)
                segment = currNode.getSegment();
        }
    }
    private void blankTail(Worm w){
        Segment segment;
        segment = w.getNumSegments().getTail().getSegment();
        squares[segment.getRow()]
                [segment.getCol()].setBackground(Color.WHITE);
        squares[segment.getRow()][segment.getCol()].setOpaque(false);
    }

    public int getRandomNumber() {
        int max, min, range, result;
        min = 0;
        max = 29;
        range = max - min + 1;

        result = (int) (Math.random() * range) + min;

        return result;
    }


    private void displayWinner(String winner) {
        winnerLabel.setText(winner + " worm wins!");
        myFrame.getContentPane().removeAll();
        myFrame.getContentPane().add(winnerPanel, BorderLayout.CENTER);
        myFrame.revalidate();
        myFrame.repaint();
    }

    public class MyKey implements KeyListener {
        @Override
        public void keyPressed(KeyEvent e) {
            if (!gameOver) {
                changeColor(e);
                System.out.println(e);
            }
        }

        public void changeColor(KeyEvent e) {
            if (!gameOver) {
                boolean collisionDetected = false;
                switch (e.getKeyChar()) {
                    case 'a':
                        blankTail(blackWorm);
                        blackWorm.move('l', 0, 30, redWorm);
                        collisionDetected = checkCollision();
                        updateGrid();
                        break;
                    case 's':
                        blankTail(blackWorm);
                        blackWorm.move('d', 0, 30, redWorm);
                        collisionDetected = checkCollision();
                        updateGrid();
                        break;
                    case 'd':
                        blankTail(blackWorm);
                        blackWorm.move('u', 0, 30, redWorm);
                        collisionDetected = checkCollision();
                        updateGrid();
                        break;
                    case 'f':
                        blankTail(blackWorm);
                        blackWorm.move('r', 0, 30, redWorm);
                        collisionDetected = checkCollision();
                        updateGrid();
                        break;
                    case 'h':
                        blankTail(redWorm);
                        redWorm.move('l', 0, 30, blackWorm);
                        collisionDetected = checkCollision();
                        updateGrid();
                        break;
                    case 'j':
                        blankTail(redWorm);
                        redWorm.move('d', 0, 30, blackWorm);
                        collisionDetected = checkCollision();
                        updateGrid();
                        break;
                    case 'k':
                        blankTail(redWorm);
                        redWorm.move('u', 0, 30, blackWorm);
                        collisionDetected = checkCollision();
                        updateGrid();
                        break;
                    case 'l':
                        blankTail(redWorm);
                        redWorm.move('r', 0, 30, blackWorm);
                        collisionDetected = checkCollision();
                        updateGrid();
                        break;
                }

                if (collisionDetected) {
                    displayWinner("No");
                    gameOver = true;
                }
            }
        }

        private boolean checkCollision() {
            LNode redHead = redWorm.getNumSegments().getHead();
            LNode blackHead = blackWorm.getNumSegments().getHead();
            Segment redSegment = redHead.getSegment();
            Segment blackSegment = blackHead.getSegment();

            if (redSegment.getRow() == blackSegment.getRow()
                    && redSegment.getCol() == blackSegment.getCol()) {
                return true;
            } else if (redSegment.getRow() < 0 || redSegment.getRow() >= 30
                        || redSegment.getCol() < 0
                        || redSegment.getCol() >= 30) {
                return true;
            } else if (blackSegment.getRow() < 0 || blackSegment.getRow() >= 30
                        || blackSegment.getCol() < 0
                        || blackSegment.getCol() >= 30) {
                return true;
            } else {
                return false;
            }
        }


        // overriding the keyReleased() method of KeyListener interface
        public void keyReleased(KeyEvent e) {
        }

        // overriding the keyTyped() method of KeyListener interface
        public void keyTyped(KeyEvent e) {
        }
    }

}