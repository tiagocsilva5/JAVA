/*************************************************
 /** Author:   Tiago Silva
 /*  Course:   CSC 221, Spring 2024
 /*  Lab:      Lab 8 - Final Project: Worm Game
 /*  File:     Segment
 *************************************************/
public class Segment {
    private int row;
    private int col;

    //Contructor 
    public Segment(int row, int col){
        this.row = row;
        this.col = col;
    }

    public int getRow(){
        return row;
    }

    public int getCol(){
        return col;
    }

    public void setRow(int row){
        this.row = row;
    }

    public void setCol(int col){
        this.col = col;
    }

    public boolean equals(int newRow, int newCol) {
        boolean isEqual;

        isEqual = false;

        if (newRow == row && newCol == col) {
            isEqual = true;
        }

        return isEqual;
    }

    public String toString() {
        return "Row: " + getRow() + ", Column: " + getCol();
    }
}