/*************************************************
 /** Author:   Tiago Silva
 /*  Course:   CSC 221, Spring 2024
 /*  Lab:      Lab 8 - Final Project: Worm Game
 /*  File:     Catch
 /*  File:     CatchDriver
 *************************************************/
public class CatchDriver {
    public static void main(String[] args) {
        Catch game;

        game = new Catch();
    }
}