/******************************************************
 * Author:      Dr. Cathy Bareiss
 * Modifier:    Tiago Silva
 * Course:      CSC 121
 * Assignment:  Maintain Inventories Arrays
*******************************************************/

import java.io.*;
import java.util.*;

public class Inventory {
    public static final int ITEMS = 0;
    public static final int INVENTORY = 1;
    public static final int REORDER = 2;
    public static final int INPUT = 3;
    public static final int TEMP = 4;
    public static final char STATUS = '=';
    public static final char ADD = '+';
    public static final char DELETE = '-';
    public static final char QUIT = '!';
    
    public static void main(String[] args) {
     // declarations
        Scanner input;
        String[] items;
        int[] inventory, reorder;
        char command; 
        items = loadArrayString(args[ITEMS]);
        inventory = loadArrayInt(args[INVENTORY]); 
        reorder = loadArrayInt(args[REORDER]); 

        // opening command file
        try {
            input = new Scanner(new FileReader(args[INPUT]));
        
        } catch (IOException e) {
            System.err.println("Trouble opening the file.");
            System.err.println("Please run again. Use the right file.");
            return;
        }
        
        command = input.nextLine().charAt(0);
        while (command != QUIT) { 
            commandProcesser(command, items, inventory, reorder,
                           input, args[TEMP], args[INVENTORY]);
            input.nextLine();
            command = input.nextLine().charAt(0);
        }      
        input.close();
    }
    
    public static void commandProcesser(char instruction, String[] itemsArray,
                                      int[] inventoryArray, int[] minArray,
                                      Scanner input, String outputName, String inventory) {
      String item;
      int amount, location;  
      item = getItem(input);
      location = itemFinder(item, itemsArray);
      switch (instruction) {
          
          case STATUS: itemDisplay(item, location, inventoryArray, minArray);
                       break;
          
          case DELETE: amount = -1 * getNumber(input);
                        itemUpdater(location, amount, inventoryArray, 
                                  outputName);
                       fileCopy(outputName, inventory);           
                       break;

          case ADD:    amount = getNumber(input);
                        itemUpdater(location, amount, inventoryArray, 
                                  outputName);
                       fileCopy(outputName, inventory);
                       break;
      }        
    }
    
    public static void itemDisplay(String item, int location,
                                   int[] inventoryArray, int[] minArray) {
      int curAmount, control;

      curAmount = inventoryArray[location];
      control = minArray[location];
      System.out.println(item+" in stock: "+curAmount+"    min: "
                         +control);
    }
    
    public static int[] loadArrayInt(String fileName) { // Dr.Bareiss made it
        Scanner file;
        int n;
        int[] values;
        
        try {
            file = new Scanner(new FileReader(fileName));
        } catch (IOException e) {
            System.err.println("problems loading file");
            return null; // no numbers read because bad file
        }
        n = 0;
        values = new int[1000];
        while (file.hasNext()) {
            values[n] = file.nextInt();
            n++;
        }
        return values;
    }
    
    public static String[] loadArrayString(String fileName) { // Dr.Bareiss made it
        Scanner file;
        int n;
        String[] items;
        
        try {
            file = new Scanner(new FileReader(fileName));
        } catch (IOException e) {
            System.err.println("problems loading file");
            return null; // no numbers read because bad file
        }
        n = 0;
        items = new String[1000];
        while (file.hasNext()) {
            items[n] = file.next();
            n++;
        }
        return items;
    }
    
      public static void itemUpdater(int location, int amount, int[] inArray, String outName) {                           
 
        int curAmount, i;
        PrintStream output;
        curAmount = inArray[location];
        
        try {
            output = new PrintStream(outName);
        } catch (IOException e) {
            System.err.println("Trouble opening the output file");
            return;
        }                
        for(i = 0; i <= location; i++) {
            curAmount = inArray[i];
            if (i == location)    // update amount
              output.println(""+(curAmount+amount));
            else                        // save amount of unchanged item
              output.println(""+curAmount);        
        } 
      }
    
      public static int itemFinder(String item, String[] arrayName) {
        int i;
        boolean found;
        found = false;
        for (i = 0; i <= arrayName.length && !found; i++) {
            if (item.equals(arrayName[i])) {
               found = true;
               return i;
            }   
        }
        return -1;
    }
    
    public static int getNumber(Scanner source) {
       int amount;
       amount = source.nextInt();
       return amount;
    }
        
    // simple get the next item from a file
    public static String getItem(Scanner source) {
        return source.next();
    }
    
    public static void fileCopy(String srcName, String destName) {
        Scanner src;
        PrintStream dest;
        
        try {
            src = new Scanner(new FileReader(srcName));
            dest = new PrintStream(destName);
        } catch (IOException e) {
            System.err.println("Trouble copying.");
            return;
        }
       
        while (src.hasNext()) dest.println(src.nextLine());
        
        src.close();
        dest.close();
    }
}