/****************************************************
 * Author:      Dr. Cathy Bareiss
 * Modifier:    Tiago Silva
 * Course:      CSC 121
 * Assignment:  Third Lab Program
*****************************************************/
import java.io.*;
import java.util.*;

public class Calculator {
    public static void main(String[] args) {    
        //declarations
        Scanner keyboard;
        char operation;
        int number;
        int answer;
        int memory;
   
        //input 
        keyboard = new Scanner(System.in);
        number = 0;
        answer = 0;
        memory = 0;
        System.out.println(
        "Please input operation and number (ex. + 5). (Space is essential). "+
        "To clear, use 'c'. To terminate, use =");
        operation = keyboard.next().charAt(0);
        
        //calculation
        while (operation != '=') { 
            System.out.println(operation);
            if (operation != 'c') number = keyboard.nextInt();
            switch (operation) { 
               case '+': answer = answer + number;
                         System.out.println("Result = " + answer);
                         break;
                
               case '-': answer = answer - number;
                         System.out.println("Result = " + answer);
                         break; 
              
               case '/': answer = answer / number; 
                         System.out.println("Result = " + answer);
                         break;
             
               case '*': answer = answer * number; 
                         System.out.println("Result = " + answer);
                         break;
            
               case 'c': answer = 0;
                         System.out.println(
                         "Calculator Cleared. Result = " + answer); 
                         break;
            
               default: System.out.println("Invalid Input' try again!"); 
            }  // close switch
            operation = keyboard.next().charAt(0);             
        } // closes loop
         System.out.println(answer);
     } // closes main
                     
   } // closes class