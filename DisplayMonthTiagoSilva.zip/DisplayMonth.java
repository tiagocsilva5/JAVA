/****************************************************
 * Author:      Dr. Cathy Bareiss
 * Modifier:    Tiago Silva
 * Course:      CSC 121
 * Assignment:  Fourth Lab Program
*****************************************************/
import java.io.*;
import java.util.*;

public class DisplayMonth {
    public static void main(String[] args) {    
        //declarations 
        Scanner keyboard; 
        int year; 
        int month;
        int day, numDays;
        int i;
        int j;
        int numRows;
        
        //input 
        keyboard = new Scanner(System.in);
        System.out.print(
        "Input the year, followed by the month, and the day it starts on");
        System.out.print(" with Sunday being 0 and Saturday being 6).");
        year = keyboard.nextInt();
        month = keyboard.nextInt();
        day = keyboard.nextInt();
        numRows = 0;
        numDays = 0;
        
        //calculations 
        
        switch(month){
            case 1: System.out.println("Janeiro"); numDays = 31; break;
            case 2: System.out.println("Fevereiro"); 
                    if (year%4 != 0) numDays = 28;
                    else if (year%100 == 0 && year%400 != 0) numDays = 28;
                    else numDays = 29;
                    break;
            case 3: System.out.println("Marco"); numDays = 31; break;
            case 4: System.out.println("Abril"); numDays = 30; break;
            case 5: System.out.println("Maio"); numDays = 31; break;
            case 6: System.out.println("Junho"); numDays = 30; break;
            case 7: System.out.println("Julho"); numDays = 31; break;
            case 8: System.out.println("Agosto"); numDays = 31; break;
            case 9: System.out.println("Setembro"); numDays = 30; break;
            case 10: System.out.println("Outubro"); numDays = 31; break;
            case 11: System.out.println("Novembro"); numDays = 30; break;
            case 12: System.out.println("Dezembro"); numDays = 31; break;
            default: 
             System.out.println("Thats not a month in portuguese. Try again!");
        }
            
              
               for ( j = 1; j<= numDays; j++) {
                 numRows++;
                    if (j==1){
                        switch(day){ 
                            case 0: System.out.print(""); 
                             numRows = 0;
                             break; 
                            case 1:
                             System.out.print("    ");
                             numRows = 1; 
                             break; 
                            case 2:
                             System.out.print("        ");
                             numRows = 2; 
                             break;  
                            case 3:
                             System.out.print("            ");
                             numRows = 3; 
                             break;
                            case 4:
                             System.out.print("                "); 
                             numRows = 4;
                             break;
                            case 5:
                             System.out.print("                    ");
                             numRows = 5; 
                             break;
                            case 6:
                             System.out.print("                        ");
                             numRows = 6;
                            break;
                        }
                    }
                    else if (numRows%7 == 0){ 
                      System.out.println(" ");
                    }
                    else if (j <= 10){ 
                      System.out.print(" "); 
                    }      
              System.out.print(" " + j + " ");
              }       
    }
}    