/****************************************************
 * Author:      Dr. Cathy Bareiss
 * Modifier:    Tiago Silva
 * Course:      CSC 121
 * Assignment:  Sixth Lab Program
*****************************************************/
import java.io.*;
import java.util.*;

public class Reorder{
    public static final String NAMES = "names.txt";
    public static final String ONHAND = "onhand.txt";        // constants
    public static final String MINAMOUNT = "minamount.txt";
    
    
    public static void main(String[] args) throws IOException { 
         Scanner keyboard;
         String item, message; 
         keyboard = new Scanner(System.in);
         System.out.println(
         "What item do you want to check on(quit to exit)?");
         item = keyboard.nextLine();
         while (!item.equals("quit")){        
            message = itemProcesser(item);
            System.out.println(message);   
            System.out.println(
            "What item do you want to check on(quit to exit)?");
            item = keyboard.nextLine();           
         }          
    }
       
     public static String itemProcesser(String item) throws IOException {
        int line, onHand, minAmount;
        int numMissing;
        line = getLineNumber(item, NAMES);
        onHand = getNumberInLine(line, ONHAND);
        minAmount = getNumberInLine(line, MINAMOUNT);
        
        if(onHand == -1) return ("This item does not exist");
        else if(onHand >= minAmount){ 
          return ("There is no need to reorder " + item); }
        else { numMissing = minAmount - onHand; 
          return ("Please order at least " + numMissing + " of " + item);
        }
     }

     public static int getLineNumber (String item, String fileName) 
        throws IOException {
        Scanner file;
        int lineNumber, counter;
        String name;        
        file = new Scanner(new FileReader(fileName));
        boolean itemExists;
        itemExists = false;
       
        try {file = new Scanner(new FileReader(fileName));}
          catch (IOException e) { 
            return -1;
          }       

        counter = 0; 
        lineNumber = 0;
        while (file.hasNext()) {
            counter++;
            name = file.nextLine();
            if (name.equals(item)){
            itemExists = true;
            lineNumber = counter;
            } 
        }
        
        if (itemExists == false) return -1;
        file.close();
        return lineNumber;
      }  
       
        public static int getNumberInLine(int line, String nameFile){
         Scanner file;
         int counter, number, numFinal;
         file = new Scanner(System.in);
      
         try {file = new Scanner(new FileReader(nameFile));}
           catch (IOException e) {
            System.out.println("Problem with the file.");
            System.exit(0);
         }
         numFinal = 0;
         counter = 0;
         if (line == -1) return -1;   
            while (file.hasNext()) {
               counter++;
               number = file.nextInt();
               if(counter == line) numFinal = number;
            }      
         file.close();
         return numFinal;
         }

        
        
        
}
    