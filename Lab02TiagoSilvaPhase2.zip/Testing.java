/*******************************************
/** Author:   Dr. Cathy Bareiss
/*  Modifier: Tiago Silva
/*  Course:   CSC 122, Spring 2024
/*  Lab:      Lab 2: Testing
/*  Class:    Testing
/*  Related classes:  Instructions, Instruction, Tape
*******************************************/
import java.io.IOException;
import java.io.*;
import java.util.*;

public class Testing {
    public static void main(String[] args) throws IOException{
        // Instructions class
        testInstsConst();
        testAddInst();
        testFind();
        //testInstsErr1();
        
        
        //Instruction class
        testInstConst();
        testEqual();
        testGetNewChar();
        testGetDirection();
        testGetNewState();
        //testErr1();
        //testErr2();
        
        //Tape class
        testTapeConst();
        testRead();
        testWrite();
        testMove();
        //testTapeErr1();
        
        // TuringMachine 
        testTM();

    }
    
    // INSTRUCTIONS

     public static void testInstsConst() {
         Instructions s1;
         
         s1 = new Instructions();
         System.out.println(s1.toString());
     }
   
     public static void testAddInst() {
         Instructions s1;
         Instruction t1;
         
         s1 = new Instructions();
         t1 = new Instruction(1,'a','b', -1, 0);
         
         // Add new instruction
         s1.addInstruction(t1);
         
         //Add parameters 
         s1.addInstruction(1, 'a', 'b', -1, 0);
         System.out.println(s1.toString());
         
     }
     
     public static void testFind() {
         Instructions s1;
         
         s1 = new Instructions();
         s1.addInstruction(1, 'a', 'b', -1, 0);
         System.out.println(s1.find(0, 'a'));
         System.out.println(s1.find(-1, 'a'));
     } 
     
     /*public static void testInstsErr1() {
         Instructions s1;
         
         s1 = new Instructions("abcd");
         System.out.println(s1.toString());
     }
     */
    
    // INSTRUCTION 
   
    public static void testInstConst() {
        Instruction t1,t2;
        
        // Test constructor
        t1 = new Instruction(1, 'a', 'b', -1, 0);
        System.out.println(t1.toString());
        
        // Test constructor with String
        t2 = new Instruction ("0,a, b,1,2");
        System.out.println(t2.toString());
        
    }
    
    public static void testEqual() {
        Instruction t1;
        
        t1 = new Instruction(1,'a', 'b',-1, 0);
        System.out.println(t1.equals(1,'a'));
        System.out.println(t1.equals(2,'a'));
        System.out.println(t1.equals(1,'b'));
        System.out.println(t1.equals(2,'b'));
    }
    
    public static void testGetNewChar() {
        Instruction t1;
        
        t1 = new Instruction(1,'a','b', -1, 0);
        System.out.println(t1.getNewChar());
    }
    
    public static void testGetDirection() {
        Instruction t1;
        
        t1 = new Instruction (1, 'a','b', -1, 0);
        System.out.println(t1.getDirection());
    }

     public static void testGetNewState() {
         Instruction t1;
         
         t1 = new Instruction(1,'a','b', -1, 0);
         System.out.println(t1.getNewState());
     }
     
     // Wrong type
     /*public static void testErr1() {
         Instruction t1;
         
         t1 = new Instruction(0,5, "b", 1, 2);
         System.out.println(t1.getNewState());
     }
     */
     
     // Wrong input
     /*public static void testErr2() {
         Instruction t1;
         
         t1 = new Instruction(1,'a', 5, -1, 0);
         System.out.println(t1.getNewState());
     }*/
 
          
     // TAPE 

    public static void testTapeConst() {
        Tape tp;

        tp = new Tape("abc");
        System.out.println(tp.toString());
    }

    public static void testRead() {
        Tape tp;

        tp = new Tape("abcd");
        System.out.println(tp.readTape());
    }
    
    public static void testWrite() {
        Tape tp;

        tp = new Tape("abc");
        tp.writeTape('d');
        System.out.println(tp.toString());
    }

    public static void testMove() {
        Tape tp;

        tp = new Tape("abc");
        tp.moveHead(1);
        System.out.println(tp.toString());
    }

    /*public static void testTapeErr1() {
        Tape tp;

        tp = new Tape(123);
    }
    */

    // TuringMachine 

    public static void testTM() throws IOException {
        TuringMachine tm;

        tm = new TuringMachine("add1Ex1");
        tm.run();
    }



}