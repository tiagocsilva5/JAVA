/*******************************************
/** Author:   Dr. Cathy Bareiss
/*  Modifier: Tiago Silva
/*  Course:   CSC 122, Spring 2024
/*  Lab:      Lab 2: Testing
/*  Class:    Tape
/*  Related classes:  Instructions, Instruction, Tape
*******************************************/
public class Tape {
    private String myTape;
    private int head;
    
    public Tape(String inStr) {
        myTape = inStr;
        head = 0;
    }
    
    public char readTape() {
        return myTape.charAt(head);
    }
    
    public void writeTape(char newChar) {
        String front, end;
        front = myTape.substring(0,head);             //changed 
        end = myTape.substring(head,myTape.length()); //changed
        myTape =  front + newChar + end; //changed
    }
    
    public void moveHead(int direction) {
        head += direction;
    }
    
    public String toString() {
        return myTape+" head at "+head;
    }
}