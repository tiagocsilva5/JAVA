/*******************************************
/** Author:   Dr. Cathy Bareiss
/*  Modifier: Tiago Silva
/*  Course:   CSC 122, Spring 2024
/*  Lab:      Lab 1: Finite State Machine
/*  Created:  August 2022
/*  Class:    Transitions: an array of transitions
/*  Related classes:  Transition
/*  COMMENT:  Be sure to comment the rest of the code
*******************************************/
public class Transitions {
    public static final int MAX=100;
    private Transition[] transitions; //constants
    private int n;
    
    public Transitions () {
        int i;
        
        transitions = new Transition[MAX];
        n = 0;
        for (i=0; i < MAX; i++) transitions[i] = null;
    }
    
    public Transitions(int num) {
        int i;
        
        transitions = new Transition[num];
        n = 0;
        for (i=0; i < num; i++) transitions[i] = null;
    }
    
    // add a transition to the array
    public void addTransition(Transition newTrans) {
        transitions[n] = newTrans;
        n++;
    }
    
    // add a transition to the array with individual components
    public void addTransition(int olds, int news, char chr) {
        Transition newTrans;
        newTrans = new Transition(olds, news, chr);
        addTransition(newTrans);
    }
   
    // look up a transition based on old state and input character
    public Transition lookup(int olds, char chr) {
        int i;
        boolean found;
        
        found = false;
        i = 0;
        
        while (i < n && !found)
            if (transitions[i].equals(olds,chr)) found = true;
            else i++;
        if (found) return transitions[i];
        return null;
    }
    
    // check if the set of transitions is deterministic
    public boolean isDeterministic() {
        int i, j;
        boolean valid;
        
        valid = true;
        i = 0;
        while (i < n && valid) {
            if (transitions[i].getChr() == ' ') valid = false;
            j = i+1;
            while (j < n && valid) {
                if (transitions[i].equals(transitions[j]))
                    valid = false;
                j++;
            }
            i++;
        }
        return valid;
    }
    
    // Method to represent the Transitions object as a string
    public String toString() {
        String result;
        int i;
        
        result = "";
        for (i=0; i< n; i++)
            result += transitions[i].toString()+"\n";
        return result;
    }
}
