/*******************************************
/** Author:   Dr. Cathy Bareiss
/*  Modifier: Tiago Silva
/*  Course:   CSC 122, Spring 2024
/*  Lab:      Lab 1: Finite State Machine
/*  Created:  August 2022
/*  Class:    FSMDriver: Creates the machine and tests strings
/*  Related classes:  FSM
/*  COMMENT:  Be sure to comment the rest of the code
*******************************************/
import java.io.*;
import java.util.*;

public class FSMDriver {
    public static void main(String[] args) throws IOException {
        FSM myFSM;
        
        myFSM = new FSM("simple");
        System.out.println(myFSM.test("+"));
    }
}
