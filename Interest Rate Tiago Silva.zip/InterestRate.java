/****************************************************
 * Author:      Dr. Cathy Bareiss
 * Modifier:    Tiago Silva
 * Course:      CSC 121
 * Assignment:  First Lab Sample.  Does simple
 *              arithmetic
*****************************************************/
import java.io.*;
import java.util.*;

public class InterestRate {
    public static void main(String[] args) {
        // declarations
        Scanner keyboard;
        double price;
        double rate;
        double interest;
        double total;
        // input
        keyboard = new Scanner(System.in);
        System.out.println("I will do some simple arithmetic for you.");
        System.out.println("What is the original price?");
        price = keyboard.nextDouble();
        System.out.println("What is the interest rate (10% is 0.1)?");
        rate = keyboard.nextDouble();
        // calculations
        interest = rate * price;
        total = price + interest;
       
        // output results
        System.out.println("You will pay " +interest +" interest on the item");
        System.out.println("The total cost will be " +total);
       
    }
}