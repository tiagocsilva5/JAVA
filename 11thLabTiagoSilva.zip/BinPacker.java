/******************************************************
 * Author:      Dr. Cathy Bareiss
 * Modifier:    Tiago Silva
 * Course:      CSC 121
 * Assignment:  Sorting and searching vs. searching
 * File:        Control class
*******************************************************/
import java.io.*;
import java.util.*;

public class BinPacker{
    //constants
    public static final int MAXWEIGHT = 100; //max weight in each container
    public static final int NUMCONTAINERS = 4; //max container in each ship
    public static final int NUMSHIPS = 3; //number of ships available
    public static final String FILE = "items.txt"; //file 
   
    public static void main(String[] args)  {
        Scanner file;
        int[][] array2D;
        int counter;
        int item;
        counter = 0;
        array2D = new int[NUMSHIPS][NUMCONTAINERS];
       
        try{
            file = new Scanner(new FileReader(FILE));
            counter = 0;
            item = 0;
        
        while (file.hasNext()){
              counter++;
              item = file.nextInt();
              itemPacker(array2D, item);
        }

        
        printOutput(array2D, file);
        analyzeStatus(array2D);
        file.close();
        
        }
        
        catch(IOException e){
              System.err.println("Problems with file");
              System.exit(-1);
        }
    }
    
    //pack an item into the first available container
    public static void itemPacker(int[][] array2D, int item){
        int ships;
        int container;
        int temp;
        int rightShip;
        int rightContainer;
        boolean space;
        boolean stored;
        space = false;
        stored = false;
        rightShip = 0;
        rightContainer = 0;
        
        for (ships = 0; ships < NUMSHIPS; ships++){
            for (container = 0; container < NUMCONTAINERS; container++){
                temp = array2D[ships][container] + item;
                if(temp <= MAXWEIGHT && space == false){
                  space = true;
                  rightShip = ships;
                  rightContainer = container;
                  array2D[ships][container] += item;
                  stored = true;
                }
            }
        }
        if (stored == false) {
            System.err.println("There is no more space");      
            System.exit(0);
        }
    }
    // this method just outputs the results
    public static void printOutput(int[][]array2D, Scanner file){
        int ships;
        int container;
        int count;
        int item;
        int notFull;
        item = 0;
        count = 0;
        
        System.out.println("Here is your report:");
        for (ships = 0; ships < NUMSHIPS; ships++){
            count = 0;
            System.out.println("");
            System.out.println("Ship:" + ships);
            System.out.println("");
            for (container = 0; container < NUMCONTAINERS; container++){
                System.out.println("Container " + container + ":" + 
                                   array2D[ships][container]);
                if (array2D[ships][container] < MAXWEIGHT){
                   count++;
                }
            }
            
            System.out.println(count + " containers are not full");
        }
    }
    
    // analyze the container status
    public static void analyzeStatus(int[][] array2D) {
        int additionalWeight;
        int totalCapacity;
        double percentage;
        additionalWeight = 0;
        totalCapacity = NUMSHIPS * NUMCONTAINERS * MAXWEIGHT;
        
        
        for (int ships = 0; ships < NUMSHIPS; ships++) {
            for (int container = 0; container < NUMCONTAINERS; container++) {
                additionalWeight += MAXWEIGHT - array2D[ships][container];
            }
        }
        
        System.out.println(additionalWeight + " more weight can be carried.");
        percentage = (double) additionalWeight / totalCapacity * 100; // net
        System.out.println("This represents " + percentage + 
                           " percentage wasted.");
    }
}

