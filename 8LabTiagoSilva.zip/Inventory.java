/****************************************************
 * Author:      Dr. Cathy Bareiss
 * Modifier:    Tiago Silva
 * Course:      CSC 121
 * Assignment:  8th Lab Program
*****************************************************/
import java.io.*;
import java.util.*;

public class Inventory {
    public static final String MIN = "onhand.txt";
    public static final String ITEMS = "names.txt";
    public static final String INVENTORY = "inventory.txt";
    public static final String INPUT = "input.txt";
    public static final String TEMP = "temp.tmp"; // andre's help
    public static final String EQUALS = "=";
    public static final String ADD = "+";
    public static final String SUBTRACT = "-";
    public static final String QUIT = "!";    
   
   
    public static void main(String[] args) {
        Scanner file;
        try{
            file = new Scanner(new FileReader(INPUT));
            commandProcesser(file);
            file.close();
        }
        catch(IOException e){
          System.err.println("Problem with Main File");
          System.exit(-1);
        } 
 
    }
    
 
    public static void commandProcesser(Scanner file) {
        String numItems, item;
        char operator;
        int counter, itemLine, newItems, number;
        counter = 0;
      
        while (file.hasNext()) {
          counter++;
          numItems = file.nextLine();
          switch (numItems) {
             case ADD: 
                  copyFileChanged(INVENTORY, TEMP, 
                                  getLineNumber(file.next(), ITEMS),
                                  file.nextInt(), true);
                  copyFileUnchanged(TEMP, INVENTORY);
                  break;
             case SUBTRACT: 
                  copyFileChanged(INVENTORY, TEMP, 
                                  getLineNumber(file.next(), ITEMS), 
                                  file.nextInt(), false); 
                  copyFileUnchanged(TEMP, INVENTORY);
                  break;
             case EQUALS: 
                  item = file.next();
                  statusDisplay(item); 
                  break;
             case QUIT:
                  break;
         }
      }

    }
    
    public static void copyFileUnchanged(String nameInFile,String nameOutFile){ 
        Scanner inFile;
        PrintWriter outFile;
        int followingNumber;
        
        try{ 
            inFile = new Scanner(new FileReader(nameInFile));
            outFile = new PrintWriter(new FileOutputStream(nameOutFile));
            while(inFile.hasNext()) {
               followingNumber = inFile.nextInt();
               outFile.println(followingNumber);
            }
            inFile.close();
            outFile.close();
        }
        catch(IOException e) {
            System.err.print("Problem copying file" + nameInFile + "to" 
                              + nameOutFile + "Ending the program");
            System.exit(-1);
        }
    }
    
    public static void copyFileChanged(String nameInFile, String nameOutFile,
        int line, int integer, boolean addition){
        Scanner inFile;
        PrintWriter outFile;                              // professor's code
        int followingNumber,counter;
       
        try {
           inFile = new Scanner(new FileReader(nameInFile));
           outFile = new PrintWriter(new FileOutputStream(nameOutFile));
           counter = 0;
           while (inFile.hasNext()) {
              counter++;
              followingNumber = inFile.nextInt();
              if(counter == line && addition == true) 
                outFile.println(followingNumber + integer);
              else if(counter == line && addition == false) 
                if (followingNumber - integer < 0) {
                outFile.println(0);
                }
                else outFile.println(followingNumber - integer);
                else outFile.println(followingNumber);
           }
         inFile.close();
         outFile.close();
         
        } 
       catch (IOException error ) {
         System.err.println("Problem copying file" + nameInFile + " to " +
                            nameOutFile + ". Ending program");
         System.exit(-1);
      }    

    }
    
    public static void statusDisplay(String item){
        Scanner file;
        int counter, line;
        String numItems;
        
        try{
            file = new Scanner(new FileReader(INVENTORY));
            line = getLineNumber(item, ITEMS);
            counter = 0;
            while(file.hasNext()) {
               counter++;
               numItems = file.next();
               if(counter == line){
                 System.out.println("Current number of "+ item + "(s) is: " 
                                    + numItems);
               }
            }
        file.close(); 
        }
        catch(IOException e) {
           System.err.println("Error");
        }      
    }
  
    public static int getIntinLine(int line, String fileName) { 
        Scanner file;
        int counter, number, numFinal;
        numFinal = 0;
      
        try {
             file = new Scanner(new FileReader(fileName));
             counter = 0;
             while (file.hasNext()) {
               counter++;
               number = file.nextInt();
               if(counter == line) {
                  numFinal = number;
               }
             }
        } 
        catch (IOException e) {
            System.err.println("Problem while searching for the line");
            return 0;
        }    
      file.close();
      return numFinal;
      
    }
       
    
    public static int getLineNumber(String item, String fileName) {
        Scanner file;
        int lineNumber, counter;
        String name;        
       
        try {
             file = new Scanner(new FileReader(fileName));
             counter = 0;
             lineNumber = 0;
             while(file.hasNext()) {
               counter++;
               name = file.next();
               if(name.equals(item)){
                  lineNumber = counter;
               }
             }
        }
            
        catch (IOException e) { 
             System.err.println("Item not found");
             return -1;
        }       
            
        file.close();
        return lineNumber;
    
    }
    
    
}
