/****************************************************
 * Author:      Dr. Cathy Bareiss
 * Modifier:    Tiago Silva
 * Course:      CSC 121
 * Assignment:  Second Lab Program
*****************************************************/
import java.io.*;
import java.util.*;

public class Arithmetic {
    public static void main(String[] args) {
    
    // declarations
    Scanner keyboard;  
    int FirstNumber;
    int SecondNumber;
    int FirstAnswer;
    int answer;
    char oper;
       
    //input 
    keyboard = new Scanner(System.in);
    System.out.println("What is the first number? (Integers only)");
    FirstNumber = keyboard.nextInt();
    System.out.println("What operation (+, -, *, /)? ");
    oper= keyboard.next().charAt(0);
    if (oper == '+'||oper == '-'||oper == '/'||oper == '*'){
        System.out.println("What is the second number? (Integers only)");
        SecondNumber = keyboard.nextInt();
        System.out.println("What do you think the answer is? ");
        FirstAnswer = keyboard.nextInt();
        answer = 0;
        
     //operations 
     if (oper == '+')
        answer = FirstNumber + SecondNumber;
     else if (oper == '-')
        answer = FirstNumber - SecondNumber;
     else if (oper == '*')
        answer = FirstNumber * SecondNumber;
     else if (oper == '/')
        answer = FirstNumber / SecondNumber;
        
      //output results 
      
     if (FirstAnswer == answer)
        System.out.println("You are right!!");
     else 
        System.out.println("You are wrong. Try again!");
}
     else System.out.println("Invalid Input");
     
     }
} 
     
    
    
     