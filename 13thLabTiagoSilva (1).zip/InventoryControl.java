/******************************************************
 * Author:      Dr. Cathy Bareiss
 * Modifier:    Tiago Silva
 * Course:      CSC 121
 * Assignment:  Thirteenth Lab
*******************************************************/
import java.io.*;
import java.util.*;

public class InventoryControl {
    public static final int LOAD = 0;
    public static final int SAVE = 1;
    public static final int INDIV_REPORT = 2;
    public static final int FULL_REPORT = 3;
    public static final int REODER_REPORT = 4;
    public static final int UPDATE_INVENTORY = 5;
    public static final int UPDATE_REORDER = 6;
    public static final int ADD_ITEM = 7;
    public static final int REMOVE_ITEM = 8;
    public static final int QUIT = 9;
    public static final int ERROR = -1;
    public static final String FILENAME = "inventory.txt";
   
    public static void main(String[] args) {
        int command;
        Scanner keyboard;
        Inventory invt;
        keyboard = new Scanner(System.in);
        invt = new Inventory();
        displayMenu();
        command = getCommand(keyboard);
        
        while (command != QUIT) {
            if (command == ERROR) {
                System.out.println("Invalid input");
            }    
            executeCommand(keyboard, command, invt);
            displayMenu();
            command = getCommand(keyboard);
        } 

    }
     
    public static int getCommand(Scanner keyboard) {
        int nextInt;
        System.out.println("Enter your choice: ");
        
        while (!keyboard.hasNextInt()) {
           System.out.println("Invalid output");
           keyboard.next();
        }
        nextInt = keyboard.nextInt();
        if (isValid(nextInt) == true) {
           return nextInt;
        }
        else return -1;
    }
    
    public static void displayMenu() {
        System.out.println("Options:");
        System.out.println("\t"+LOAD+") load data from file");
        System.out.println("\t"+SAVE+") save data from file");
        System.out.println("\t"+INDIV_REPORT+") get status of an item");
        System.out.println("\t"+FULL_REPORT+") get status of all items");
        System.out.println("\t"+REODER_REPORT+") get a list for reordering");
        System.out.println("\t"+UPDATE_INVENTORY+
                           ") update inventory of an item");
        System.out.println("\t"+UPDATE_REORDER+
                           ") update the reorder level of an item");
        System.out.println("\t"+ADD_ITEM+") add an item to the inventory");
        System.out.println("\t"+REMOVE_ITEM+
                           ") remove an item from the inventory");
        System.out.println("\t"+QUIT+") quit");
    }
    
    public static boolean isValid(int value) {
        return value >= LOAD && value <= QUIT;   
       
    }
    
    public static void executeCommand(Scanner keyboard, int command, 
                               Inventory invt) {
        switch (command) {
            case LOAD:              load(invt); break;
            case SAVE:              save(keyboard, invt); break;
            case INDIV_REPORT:      indivReport(keyboard, invt); break;
            case FULL_REPORT:       fullReport(invt); break;
            case REODER_REPORT:     reorderReport(invt); break;
            case UPDATE_INVENTORY:  updateInventory(keyboard, invt); break;
            case UPDATE_REORDER:    updateReorder(keyboard, invt); break;
            case ADD_ITEM:          addItem(keyboard, invt); break;
            case REMOVE_ITEM:       removeItem(keyboard, invt); break;        
       }
    }
    public static void load(Inventory invt) {
        Scanner datafile, keyboard;
        String name, fileName;
        int amount, level;
        Item newItem;
        keyboard = new Scanner(System.in);
        System.out.println("Name of the file: ");
        fileName = keyboard.nextLine();
        try {
            datafile = new Scanner(new FileReader(fileName));    
            
            while (datafile.hasNext()) {
                name = datafile.next();
                amount = datafile.nextInt();
                level = datafile.nextInt();
                newItem = new Item(name, amount, level);
                invt.addItem(newItem);
                System.out.println("Item: " + name);

            }
       
            datafile.close();
        
        } catch (IOException e) {
            System.out.println("Can't open that file.");
        }
    }
    
    public static void save(Scanner keyboard, Inventory invt) {
        PrintStream outfile;
        try {
            outfile = new PrintStream(FILENAME);
        } catch (IOException e) {
            System.out.println("Problems in saving to that file");
            return;
        }
        outfile.println(invt.toString());
        System.out.println("File created");
    
    }

    public static void indivReport(Scanner keyboard, Inventory invt) {
        Item desiredItem;
        String name;
        int amountNeeded;
        int amount; 
        int reorderAmount;
        boolean moreNeeded;
        moreNeeded = false;
        amountNeeded = 0;
        
        keyboard = new Scanner(System.in);
        System.out.println("What is the item?");
        name = keyboard.next();
        amount = -1;
        reorderAmount = -1;
        
        try {
            desiredItem = invt.getItem(name);
            amount = desiredItem.getAmount();
            reorderAmount = desiredItem.getReorder();
        } 
        catch (NullPointerException e) {
            System.err.println("Item doesn't exist");
        } 
        if (amount < reorderAmount) {
            moreNeeded = true;
            amountNeeded = reorderAmount - amount;
        }    
        if (moreNeeded == true)
            System.out.println("Name: " + name 
                              + "\nAmount: " + amount 
                              + "\nReorder: " + reorderAmount + 
                               "\nYou need to reorder " + amountNeeded 
                               + " " + name);
        else if (moreNeeded == false && amount != -1) 
            System.out.println("nName: " + name 
                              + "\nAmount: " + amount 
                              + "\nReorder: " + reorderAmount);  
    }
    
    public static void fullReport(Inventory invt) {
        int i;
        for (i = 0; i < invt.length(); i++) {
            System.out.println(invt.getItem(i));
        }
    }
    
    public static void reorderReport(Inventory invt) {
        int i;
        Item item;
        for (i = 0; i < invt.length(); i++) {
            item = invt.getItem(i);
            if (item.getAmount() < item.getReorder()) {
               System.out.println(item.getName() +
                               " needs reorder. Amount to order: "
                                  + item.getReorder());
            }
        }
    }
    
    public static void updateInventory(Scanner keyboard, Inventory invt) {
        System.out.println("Name of the item: ");
        String itemName;
        int amount;
        itemName =keyboard.next();
        Item item;
        item = invt.getItem(itemName);
        
        if (item != null) {
            System.out.println("Enter the amount to add/remove: ");
            amount = keyboard.nextInt();
            System.out.println("The Inventory was updated");
        } else {
            System.out.println("Item not found");
        }
    
    }
    
    public static void updateReorder(Scanner keyboard, Inventory invt) {
        Item item;
        int i;
        for (i = 0; i <= invt.length() - 1; i++) {
            item = invt.getItem(i);   
            if (item.getAmount() < item.getReorder())
                System.out.println("\nName: " + item.getName() +
                                   "\nAmount to be ordered: " + 
                                   (item.getReorder() - item.getAmount()));
        }
    }
    
    public static void addItem(Scanner keyboard, Inventory invt) {
        String name;
        int amount;
        int reorderLevel;
        Item newItem;
        
        System.out.println("Name of the new item: ");
        name = keyboard.next();
        System.out.println("Amount: ");
        amount = keyboard.nextInt();
        System.out.println("Reorder Level: ");
        reorderLevel = keyboard.nextInt();
        newItem = new Item(name, amount, reorderLevel);
        invt.addItem(newItem);
        System.out.println("Item added");
    }
    
    public static void removeItem(Scanner keyboard, Inventory invt) {
        String itemName;
        System.out.println("Choose the item you want to remove: ");
        itemName = keyboard.next();
        invt.removeItem(itemName);
        System.out.println("Removed with success");
      
    }
}
    