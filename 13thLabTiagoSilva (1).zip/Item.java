/******************************************************
 * Author:      Dr. Cathy Bareiss
 * Modifier:    Tiago Silva
 * Course:      CSC 121
 * Assignment:  Finish Inventory project
 * File:        Item class
*******************************************************/
public class Item {
    // field variables
    private String name;
    private int amount, reorder;
    
    
    // constructors
    public Item(String inName, int inAmount, int inReorder) {
        name = inName;
        amount = inAmount;
        reorder = inReorder;
    }
    
    // accessors
    public String getName() {
        return name;
    }
    
    public int getAmount() {
        return amount;
    }
    
    public int getReorder() {
        return reorder;
    }
    
    // mutators
    public void setAmount(int inAmount) {
        amount = inAmount;
    }
    
    public void setReorder(int inReorder) {
        reorder = inReorder;
    }
    
    public void updateAmount(int addition) {
        amount += addition;
    }
    
    
    // helpers
    public boolean equals(Item other) {
        return name.equals(other.getName());
    }
    
    public boolean equals(String otherName) {
        return name.equals(otherName);
    }
    
    public int compareTo(Item other) {
        return name.compareTo(other.getName());
    }
    
    public String toString() {
        return name+"\t"+amount+"\t\t"+reorder;
    }
}