/******************************************************
 * Author:      Dr. Cathy Bareiss
 * Modifier:    Tiago Silva
 * Course:      CSC 121
 * Assignment:  Finish Inventory project
 * File:        Inventory class
*******************************************************/
import java.util.*;
import java.io.*;
public class Inventory {
    // constants
    public static final int MAX=1000;

    // field variables
    private Item[] items;
    private int n;
    
    // constructors
    public Inventory() {
        items = new Item[MAX];
        n = 0;
    }
    
    public Inventory(int size) {
        items = new Item[size];
        n = 0;
    }
    
    
    // accessors
    
    // return item associated with a location
    public Item getItem(int location) {
        return items[location];
    }

    // return item associated with a name
    public Item getItem(String name) {
        int location;
        
        location = lookup(name);
        if (location >= 0) return items[location];
        return null;
    }
    
    public int length() {
        return n;
    }
 
    // mutators
    
    // add item to bottom of list
    public void addItem(Item newItem) {
        items[n] = newItem;
        n++;
    }
    
    public void removeItem(String oldItem) {
        int location;
        int i;
        
        location = lookup(oldItem);
        if (location == -1) return;
        for (i = location; i < n-1; i++)
            items[i]=items[i+1];
        n--;
    }
    
    // uses bubble sort
    public void sort() {
        Item tempItem;
        int i, j;
        boolean swapped;
        
        swapped = true;
        i = 0;
        while (swapped && i < n-1) {
            swapped = false;
            for (j = 0; j < n-i-1; j++) {
                if (items[j].compareTo(items[j+1]) > 0) {
                    tempItem = items[j];
                    items[j] = items[j+1];
                    items[j+1] = tempItem;
                    swapped = true;
                }
            }
            i++;
        }
    }
    
    // load items from a file.  
    public void loadItems(String filename) {
        Scanner datafile;
        String name;
        int amount, level, n;
        Item newItem;
        
        try {
            datafile = new Scanner(new FileReader(filename));
        } catch (IOException e) {
            System.out.println("Can't open that file.");
            return;
        }
        while (datafile.hasNext()) {
            name = datafile.next();
            amount = datafile.nextInt();
            level = datafile.nextInt();
            newItem = new Item(name, amount, level);
            addItem(newItem);
        }
        datafile.close();
    }
    
    // save items to a file
    public void saveItems(String filename) {
        PrintStream outfile;
        
        try {
            outfile = new PrintStream(filename);
        } catch (IOException e) {
            System.out.println("Problems save to that file");
            return;
        }
        outfile.println(this.toString());
    }
    
    // internal use only methods
    
    // returns index of first item with a name
    public int lookup(String name) {
        Item temp;
        boolean found;
        int i;
        
        found = false;
        i = 0;
        while (i < n && !found) {
            if (items[i].equals(name))
                found = true;
            else
                i++;
        }
        if (found) return i;
        else return -1;
    }
    
    // returns index of a given item
    public int lookup(Item item) {
        return lookup(item.getName());
    }
    
    // helpers
    public String toString() {
        String result;
        int i;
        
        result = "";
        for (i=0; i < n; i++)
            result += items[i].toString()+"\n";
        return result;
    }
}