/*******************************************
/** Author:   Dr. Cathy Bareiss
/*  Modifier: Tiago Silva
/*  Course:   CSC 122, Spring 2024
/*  Lab:      Lab 3: Tic Tac Toe
/*  Class:    Game
/*  Related classes:  Board, GameDriver, Player, IODriver, Move
*******************************************/
import java.util.Scanner;
import java.io.*;
import java.util.*;

public class Game {
    private Board tttBoard;
    private Player xPlayer;
    private Player oPlayer;
    private Player curPlayer;
    private IODriver iosystem;
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        IODriver ioDriver = new IODriver(scanner);

        System.out.print("Enter the name for Player X: ");
        String xName = scanner.next();

        System.out.print("Enter the name for Player O: ");
        String oName = scanner.next();

        Game game = new Game(xName, oName);
        game.play();
    }

    public Game(String xName, String oName) {
        this.tttBoard = new Board();
        this.xPlayer = new Player(xName, 'X');
        this.oPlayer = new Player(oName, 'O');
        this.curPlayer = xPlayer;
        this.iosystem = new IODriver(new Scanner(System.in));
    }
    
    public Game (String fileName) {
        Scanner file;
        iosystem = new IODriver(new Scanner(System.in));
        try {
            file = new Scanner(new FileReader(fileName));
            while (file.hasNext()) {
                tttBoard = new Board(file.nextInt());
                xPlayer = new Player(file.next(), 'X');
                oPlayer = new Player(file.next(), 'O');
            }
            file.close();
        } catch (IOException e) {
            System.err.println("Problems with file");;
        }
    }

    
    public void play() {
        while (!tttBoard.gameOver() && !tttBoard.isWinner(xPlayer) 
               && !tttBoard.isWinner(oPlayer)) {
            System.out.println(tttBoard);

            takeTurn(curPlayer);
            switchPlayer();
        }

        endGame();
    }

    private void takeTurn(Player player) {
        Move move;
        System.out.println(player.getName() + "'s turn.");

        move = getMove(player);

        while (!tttBoard.isLegal(move)) {
            System.out.println("Invalid move. Try again.");
            move = getMove(player);
        }

        tttBoard.makeMove(move, player);
    }

    private Move getMove(Player player) {
        int row;
        int column; 
        row = iosystem.getInt("Enter row (0 to 2): ");
        column = iosystem.getInt("Enter column (0 to 2): ");
        return new Move(row, column);
    }

    private void switchPlayer() {
        if (curPlayer.equals(xPlayer)) {
           curPlayer = oPlayer;
        } else {
           curPlayer = xPlayer;
        }
    }
    private void endGame() {
        System.out.println(tttBoard);

        if (tttBoard.isWinner(xPlayer)) {
            System.out.println(xPlayer.getName() + " wins!");
        } else if (tttBoard.isWinner(oPlayer)) {
            System.out.println(oPlayer.getName() + " wins!");
        } else {
            System.out.println("It's a draw!");
        }
    }


}