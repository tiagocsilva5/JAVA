/*******************************************
/** Author:   Dr. Cathy Bareiss
/*  Modifier: Tiago Silva
/*  Course:   CSC 122, Spring 2024
/*  Lab:      Lab 3: Tic Tac Toe
/*  Class:    Player
/*  Related classes:  Game, GameDriver, Board, IODriver, Move
*******************************************/
import java.io.*;
import java.util.*;
public class Player {
    private String name;
    private char symbol;

    public Player(String name, char symbol) {
        this.name = name;
        this.symbol = symbol;
    }

    public String getName() {
        return name;
    }

    public char getSymbol() {
        return symbol;
    }

    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Player player = (Player) obj;
        return symbol == player.symbol && name.equals(player.name);
    }

    public String toString() {
        return "Player: " + name + "' has the symbol" + symbol;
    }
}