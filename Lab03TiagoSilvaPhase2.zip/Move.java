/*******************************************
/** Author:   Dr. Cathy Bareiss
/*  Modifier: Tiago Silva
/*  Course:   CSC 122, Spring 2024
/*  Lab:      Lab 3: Tic Tac Toe
/*  Class:    Move
/*  Related classes:  Game, GameDriver, Player, IODriver, Board
*******************************************/
import java.io.*;
import java.util.*;
public class Move {
    private int row;
    private int column;

    public Move(int row, int column) {
        this.row = row;
        this.column = column;
    }

    public int getRow() {
        return row;
    }

    public int getColumn() {
        return column;
    }

    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Move move = (Move) obj;
        return row == move.row && column == move.column;
    }

    public String toString() {
        return "Moved to row " + row + "Moved to column " + column;
    }
}