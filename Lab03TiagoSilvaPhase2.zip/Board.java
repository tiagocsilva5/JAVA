/*******************************************
/** Author:   Dr. Cathy Bareiss
/*  Modifier: Tiago Silva
/*  Course:   CSC 122, Spring 2024
/*  Lab:      Lab 3: Tic Tac Toe
/*  Class:    Board
/*  Related classes:  Game, GameDriver, Player, IODriver, Move
*******************************************/
import java.util.Scanner;
import java.io.*;
import java.util.*;
public class Board {
    private char[][] board;

    public Board() {
        this(3); // Default size is 3x3
        //to change the size of the board change the value inside of this()
    }

    public Board(int size) {
        board = new char[size][size];
        initializeBoard();
    }

    private void initializeBoard() {
        int i;
        int j;
        for (i = 0; i < board.length; i++) {
            for (j = 0; j < board[i].length; j++) {
                board[i][j] = ' ';
            }
        }
    }

    public boolean isLegal(Move move) {
        int row;
        int column;
        row = move.getRow();
        column = move.getColumn();
        
        return row >= 0 && row < board.length && column >= 0 
               && column < board[row].length && board[row][column] == ' ';
    }

    public void makeMove(Move move, Player player) {
        if (isLegal(move)) {
            board[move.getRow()][move.getColumn()] = player.getSymbol();
        }
    }

    public boolean gameOver() { //this method was taken from the internet
        //char cell;
        for (char[] row : board) {  //the char and the char[] had to be inside 
                                    //the for loop because they werent working 
                                    //if I initialized them outside
            for (char cell : row) {  //needs to be changed
                if (cell == ' ') {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean isWinner(Player player) {
        char symbol; 
        int i;
        int j;        
        symbol = player.getSymbol();

        // Check rows
        for (i = 0; i < board.length; i++) {
            if (board[i][0] == symbol && board[i][1] == symbol 
                && board[i][2] == symbol) {
            return true;
            }
        }

        // Check columns
        for (j = 0; j < board[0].length; j++) {
            if (board[0][j] == symbol && board[1][j] == symbol 
                && board[2][j] == symbol) {
            return true;
            }
        }

       // Check diagonals
       if (board[0][0] == symbol && board[1][1] == symbol 
           && board[2][2] == symbol) {
           return true; //(top-left to bottom-right)
       }
       if (board[0][2] == symbol && board[1][1] == symbol 
           && board[2][0] == symbol) {
           return true; //(top-right to bottom-left)
       }
   
       return false; 
    }
 
    public char getPiece(Move move) {
        return board[move.getRow()][move.getColumn()];
    }

    public String toString() {
        int i;
        int j;
        for (i = 0; i < board.length; i++) {
           for (j = 0; j < board[i].length; j++) {
                  System.out.print(board[i][j]);
               if (j < board[i].length - 1) {
                  System.out.print(" | ");
               }
           }
           System.out.println();
           if (i < board.length - 1) {
              System.out.println("---------");
        }
    }
    return "";
    }
}