/*******************************************
 /* Author:   Tiago Silva
 /*  Modifier:
 /*  Course:   CSC 221, Spring 2024
 /*  Lab:      Lab 3: Tic Tac Toe
 /*  Class:    Testing
 /*  Related classes: Move, Player, Board, Game
 *******************************************/

public class Testing {
    public static void main(String[] args){
        // Board
        testBoardConstructors();
        
        // Player
        testPlayerConstructor();
        testGetName();
        testGetSymbol();
        testPlayerEquals();
        
        // Move
        testMoveConstructor();
        testGetRow();
        testGetColumn();
        testMoveEquals();
        
        //testIsLegalMakeMove();
        testGameOver();
        testIsWinner();
        testGetPiece();
        
        // Game
        testGame();
    }

    //Board Class
    public static void testBoardConstructors() {
        Board board1, board2;

        board1 = new Board();
        board2 = new Board(5);
        System.out.println("--------------------");
        System.out.println(board1.toString());
        System.out.println(board2.toString());
    }

    public static void testIsLegalMakeMove() {
        Board board1;
        Move move1, move2;
        Player player1;

        board1 = new Board();
        move1 = new Move(1,1);
        move2 = new Move(1,2);
        player1 = new Player("Tiago", 'X');
        board1.makeMove(move1,player1);
        System.out.println("--------------------");
        System.out.println(board1.isLegal(move1));
        System.out.println(board1.isLegal(move2));
        board1.makeMove(move1,player1);
    }

    public static void testGameOver() {
        Board board1, board2, board3;
        Move move1, move2, move3, move4, move5, move6, move7, move8, move9;
        Player player1;

        move1 = new Move(0,0);
        move2 = new Move(0,1);
        move3 = new Move(0,2);
        move4 = new Move(1,0);
        move5 = new Move(1,1);
        move6 = new Move(1,2);
        move7 = new Move(2,0);
        move8 = new Move(2,1);
        move9 = new Move(2,2);
        board1 = new Board();
        board2 = new Board();
        player1 = new Player("Tiago", 'X');
        board2.makeMove(move1, player1);
        board2.makeMove(move2, player1);
        board2.makeMove(move3, player1);
        board2.makeMove(move4, player1);
        board2.makeMove(move5, player1);
        board2.makeMove(move6, player1);
        board2.makeMove(move7, player1);
        board2.makeMove(move8, player1);
        board2.makeMove(move9, player1);
        System.out.println(board1.gameOver());
        System.out.println(board2.gameOver());
    }

    public static void testIsWinner() {
        Board board1;
        Player player1;
        Move move1, move2, move3, move4, move5, move6, move7, move8, move9;

        board1 = new Board();
        player1 = new Player("Tiago", 'X');

        move1 = new Move(0,0);
        move2 = new Move(0,1);
        move3 = new Move(0,2);
        move4 = new Move(1,0);
        move5 = new Move(1,1);
        move6 = new Move(1,2);
        move7 = new Move(2,0);
        move8 = new Move(2,1);
        move9 = new Move(2,2);

        System.out.println("--------------------");
        board1.makeMove(move1, player1);
        board1.makeMove(move2, player1);
        board1.makeMove(move3, player1);
        System.out.println(board1.isWinner(player1));
        board1.makeMove(move4, player1);
        board1.makeMove(move5, player1);
        board1.makeMove(move6, player1);
        System.out.println(board1.isWinner(player1));
        board1.makeMove(move7, player1);
        board1.makeMove(move8, player1);
        board1.makeMove(move9, player1);
        System.out.println(board1.isWinner(player1));
        board1.makeMove(move1, player1);
        board1.makeMove(move4, player1);
        board1.makeMove(move7, player1);
        System.out.println(board1.isWinner(player1));
        board1.makeMove(move2, player1);
        board1.makeMove(move5, player1);
        board1.makeMove(move8, player1);
        System.out.println(board1.isWinner(player1));
        board1.makeMove(move3, player1);
        board1.makeMove(move6, player1);
        board1.makeMove(move9, player1);
        System.out.println(board1.isWinner(player1));
        board1.makeMove(move8, player1);
        board1.makeMove(move5, player1);
        board1.makeMove(move3, player1);
        System.out.println(board1.isWinner(player1));
    }

    public static void testGetPiece() {
        Move move1;
        Board board;
        Player player1;
        board = new Board();
        move1 = new Move(1,1);
        player1 = new Player("Tiago",'O');

        board.makeMove(move1,player1);
        System.out.println("--------------------");
        System.out.println(board.getPiece(move1));
    }
    
    //Player Class
    public static void testPlayerConstructor() {
        Player player1;

        player1 = new Player("Tiago",'X');
        System.out.println("--------------------");
        System.out.println(player1.toString());
    }

    public static void testGetName() {
        Player player1;

        player1 = new Player("Tiago",'X');
        System.out.println("--------------------");
        System.out.println(player1.getName());
    }

    public static void testGetSymbol() {
        Player player1;

        player1 = new Player("Tiago",'X');
        System.out.println("--------------------");
        System.out.println(player1.getSymbol());
    }

    public static void testPlayerEquals() {
        Player player1, player2, player3, player4;

        player1 = new Player("Tiago",'X');
        player2 = new Player("Mike",'O');
        player3 = new Player("Tiago",'O');
        player4 = new Player("Tiago",'X');
        System.out.println("--------------------");
        System.out.println(player1.equals(player2));
        System.out.println(player1.equals(player3));
        System.out.println(player1.equals(player4));
    }

    //Move Class
    public static void testMoveConstructor() {
        Move move1;

        move1 = new Move(0,0);
        System.out.println("--------------------");
        System.out.println(move1.toString());
    }
    public static void testGetRow() {
        Move move1;

        move1 = new Move(0,0);
        System.out.println("--------------------");
        System.out.println(move1.getRow());
    }
    public static void testGetColumn() {
        Move move1;

        move1 = new Move(0,0);
        System.out.println("--------------------");
        System.out.println(move1.getColumn());
    }
    public static void testMoveEquals() {
        Move move1, move2, move3;

        move1 = new Move(1,1);
        move2 = new Move(2,2);
        move3 = new Move(1,1);
        System.out.println("--------------------");
        System.out.println(move1.equals(move2));
        System.out.println(move1.equals(move3));
    }

    

    //Game Class
    public static void testGame() {
        Game game1, game2, game3;
        //game1 = new Game("test1.txt");
        game2 = new Game("Tiago", "Mike");
        System.out.println("--------------------");
        //game1.play();
        game2.play();

    }
}


