/*******************************************
/** Author:   Dr. Cathy Bareiss
/*  Modifier: Tiago Silva
/*  Course:   CSC 122, Spring 2024
/*  Lab:      Lab 3: Tic Tac Toe
/*  Class:    GameDriver
/*  Related classes:  Game, Board, Player, IODriver, Move
*******************************************/
import java.util.Scanner;
import java.io.*;
import java.util.*;
public class GameDriver {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        IODriver ioDriver = new IODriver(scanner);

        System.out.print("Enter the name for Player X: ");
        String xName = scanner.next();

        System.out.print("Enter the name for Player O: ");
        String oName = scanner.next();

        Game game = new Game(xName, oName);
        game.play();
               
/*      Game game = new Game("test1.txt");
        game.play();
*/
    }
}