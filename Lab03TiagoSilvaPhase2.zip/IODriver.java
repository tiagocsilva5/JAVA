/*******************************************
/** Author:   Dr. Cathy Bareiss
/*  Modifier: Tiago Silva
/*  Course:   CSC 122, Spring 2024
/*  Lab:      Lab 3: Tic Tac Toe
/*  Class:    IODriver
/*  Related classes:  Game, GameDriver, Player, Board, Move
*******************************************/
import java.util.Scanner;

public class IODriver {
    private Scanner inputDevice;

    public IODriver(Scanner inputDevice) {
        this.inputDevice = inputDevice;
    }

    public int getInt(String message) {
        System.out.print(message);
        return inputDevice.nextInt();
    }

    public String getString(String message) {
        System.out.print(message);
        return inputDevice.next();
    }

    public void displayMessage(String message) {
        System.out.println(message);
    }
}