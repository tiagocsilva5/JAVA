/*******************************************
/** Author:   Dr. Cathy Bareiss
/*  Modifier: Tiago Silva
/*  Course:   CSC 221, Spring 2024
/*  Lab:      Lab 7: Dining Philosophers
/*  Class:    Philosopher1
/*  Related classes: LockItemClass, Philosopher,DiningPhilosophers,Philosopher2
*******************************************/
public class Philosopher1 extends Thread implements Philosopher {
    private final int id;
    private final LockItemClass forks;

    public Philosopher1(int id, LockItemClass forks) {
        this.id = id;
        this.forks = forks;
    }

    public void run() {
        int i;
        for (i = 0; i <= 50; i++) {
            think();
            eat();
        }
    }

    public void think() {
        System.out.println("Philosopher " + id + " is thinking");
        try {
            Thread.sleep((long) (Math.random() * 1000));
        } catch (InterruptedException e) {
            System.err.println("Interrupted while thinking");
            Thread.currentThread().interrupt(); // Re-interrupt the thread
        }
    }


    // First approach. This approach gives an order of fork acquisition to
    // prevent deadlock.
    public void eat() {
        int leftFork = id;
        int rightFork = (id + 1) % forks.forks.length;

        while (true) {
            try {
                // Attempt to get both forks
                if (forks.lockFork(leftFork) && forks.lockFork(rightFork)) {
                    System.out.println("Philosopher " + id + 
                                        " picks up left and right forks");
                    System.out.println("Philosopher " + id + " is eating");
                    Thread.sleep((long) (Math.random() * 1000));
                    break; // Exit eating loop
                } else {
                    // If unable to get both forks
                    //release any acquired forks and retry
                    forks.putDownFork(leftFork);
                    forks.putDownFork(rightFork);
                    System.out.println("Philosopher " + id + 
                                       " releases forks and retries");
                    Thread.sleep((long) (Math.random() * 500));
                }
            } catch (InterruptedException e) {
                System.err.println("Interrupted while eating");
                Thread.currentThread().interrupt(); // Re-interrupt the thread
            }
        }

        // release forks in the end
        forks.putDownFork(leftFork);
        forks.putDownFork(rightFork);
        System.out.println("Philosopher " + id + " puts down forks");
    }


    public void stopThread() {
        int i, counter;

        counter = 0;
        // check for deadlock
        for (i = 0; i < forks.forks.length; i++) {
            if (forks.isLocked(i)) {
                counter++;
            }
        }
        if (counter > 1) {
            System.out.println("Stoped");
            Thread.currentThread().interrupt();
        }
    }

    @Override
    public void start() {
        super.start();
    }

}