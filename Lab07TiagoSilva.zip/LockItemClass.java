/*******************************************
/** Author:   Dr. Cathy Bareiss
/*  Modifier: Tiago Silva
/*  Course:   CSC 221, Spring 2024
/*  Lab:      Lab 7: Dining Philosophers
/*  Class:    LockItemClass
/*  Related classes:  DiningPhilosopher, Philosopher, Philosopher1,Philosopher2
*******************************************/
public class LockItemClass {
    boolean[] forks;

    public LockItemClass(int n) {
        int i;
        forks = new boolean[n];
        for (i = 0; i < n; i++) {
            forks[i] = false;
        }
    }

    //Lock fork 
    synchronized public boolean lockFork(int fork) {
        if (!forks[fork]) { 
            forks[fork] = true; // Set the fork to be locked
            return true; 
        }
        return false;

    }

    //Put down the fork
    public void putDownFork(int fork) {
        forks[fork] = false;
    }

    public boolean isLocked(int fork){
        return forks[fork];
    }
    
    public String toString(){
        String message;
        int i;

        message = "";

        for(i=0; i<forks.length; i++){
            message += "[" + forks[i] + "]";
        }

        return message;
    }
}