/*******************************************
/** Author:   Dr. Cathy Bareiss
/*  Modifier: Tiago Silva
/*  Course:   CSC 221, Spring 2024
/*  Lab:      Lab 7: Dining Philosophers
/*  Class:    DiningPhilosophers
/*  Related classes:  LockItemClass, Philosopher, Philosopher1, Philosopher2
*******************************************/
public class DiningPhilosophers {
    public static void main(String[] args) {
        //run0();
        run1();
    
    }
    
    public static void run0() {
        int i;
        LockItemClass forks; 
        Philosopher[] philosophers;
        
        forks = new LockItemClass(5);
        philosophers = new Philosopher[5];
        
        System.out.println("Method one");
        // Method one -> pick up one fork, 
        //if the second is not available, release the first
        for (i = 0; i < philosophers.length; i++)
            philosophers[i] = new Philosopher1(i, forks);

        // Start philosopher threads
        for (i = 0; i < philosophers.length; i++) {
            philosophers[i].start();
        }
    }
    
    public static void run1() {
        int i;
        LockItemClass forks;
        Philosopher[] philosophers;
        
        forks = new LockItemClass(5);
        philosophers = new Philosopher[5];

        System.out.println("Method two");
        // Second method -> If the second fork is not available,
        // put the fork down and keeps trying  
        for (i = 0; i < philosophers.length; i++)
            philosophers[i] = new Philosopher2(i, forks);

        // Start philosopher threads
        for (i = 0; i < philosophers.length; i++) {
            philosophers[i].start();
        }
    }
}