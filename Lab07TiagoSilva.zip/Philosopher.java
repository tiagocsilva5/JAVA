/*******************************************
/** Author:   Dr. Cathy Bareiss
/*  Modifier: Tiago Silva
/*  Course:   CSC 221, Spring 2024
/*  Lab:      Lab 7: Dining Philosophers
/*  Class:    Philosopher
/*  Related classes: LockItemClass,DiningPhilosopher,Philosopher1,Philosopher2
*******************************************/
interface Philosopher {
    void start();
    void think();
    void eat();
}