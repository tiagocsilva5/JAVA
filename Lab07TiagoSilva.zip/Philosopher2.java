/*******************************************
/** Author:   Dr. Cathy Bareiss
/*  Modifier: Tiago Silva
/*  Course:   CSC 221, Spring 2024
/*  Lab:      Lab 7: Dining Philosophers
/*  Class:    Philosopher2
/*  Related classes: LockItemClass, Philosopher,DiningPhilosophers,Philosopher1
*******************************************/
public class Philosopher2 extends Thread implements Philosopher {
    private final int id;
    private final LockItemClass forks;

    public Philosopher2(int id, LockItemClass forks) {
        this.id = id;
        this.forks = forks;
    }

    @Override
    public void run() {
        for (int i = 0; i < 50; i++) {
            think();
            eat();
        }
    }

    public void think() {
        System.out.println("Philosopher " + id + " is thinking");
        try {
            Thread.sleep((long) (Math.random() * 1000));
        } catch (InterruptedException e) {
            System.err.println("Interrupted while thinking");
            Thread.currentThread().interrupt();
        }
    }

    public void eat() {
        int leftFork = id;
        int rightFork = (id + 1) % forks.forks.length;
        int attempts = 0;

        while (attempts < 3) { // Allow max 3 attempts to acquire both forks
            try {
                synchronized (forks) {
                    if (forks.lockFork(leftFork)) {
                        System.out.println("Philosopher " + id + 
                                            " picks up left fork");
                        if (forks.lockFork(rightFork)) {
                            System.out.println("Philosopher " + id + 
                                                " picks up right fork");
                            System.out.println("Philosopher " + id + 
                                                " is eating");
                            Thread.sleep((long) (Math.random() * 1000));
                            return; // Exit after eating
                        } else {
                            System.out.println("Philosopher " + id + 
                                            " put down left fork due to" + 
                                            " unavailability of " + 
                                            "right fork. Retrying...");
                            forks.putDownFork(leftFork);
                        }
                    }
                }
                attempts++;
                Thread.sleep((long) (Math.random() * 500));
            } catch (InterruptedException e) {
                System.err.println("Interrupted while eating");
                Thread.currentThread().interrupt(); 
            }
        }
        System.out.println("Philosopher " + id + 
                            " gives up after multiple failed attempts to eat");
    }

    @Override
    public void start() {
        super.start();
    }
}