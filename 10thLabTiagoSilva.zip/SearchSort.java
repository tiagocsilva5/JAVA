/******************************************************
 * Author:      Dr. Cathy Bareiss
 * Modifier:    Tiago Silva
 * Course:      CSC 121
 * Assignment:  Sorting and searching vs. searching
 * File:        Control class
*******************************************************/
import java.util.*;

public class SearchSort {
    // constants
    public static final int MAX=10000000;         // largest list
  

    // run many times on different size files
    public static void main(String[] args) {
        int j;
        int i;
        for(i = 15; i <= 30; i++){
           for(j = -5; j <= 5; j++){
               processOneRun(i,i,j);
           }
        }
    }
    
    // generates data for one run, processes and finishes output with type
    public static void processOneRun( int n1, int n2, int type) {
        int[] data1;
        int[] data2;
        data1 = generateData(n1, type);
        data2 = generateData(n2, 0);
        reportOneRun(data1, data2, n1, n2);
        System.out.println(type);
    }

    // does the search vs. sort and search on one set of data
    // and reports result
    public static void reportOneRun(int[] masterData, int[] searchData, 
                                    int masterN, int searchN) {
        int numSearchOnly, numSearchSort;
        
        numSearchOnly = searchUnorder(masterData, masterN, 
                                      searchData, searchN);
        numSearchSort = searchOrdered(masterData, masterN,
                                      searchData, searchN);
        // feel free to change the output
        System.out.format("%d\t%d\t%d\t%d\t",masterN, searchN, 
                                         numSearchOnly, numSearchSort);
    }
    
    // Calls sequential search for each number in second array looking for it
    // in first array.  Assumes first array is not sorted.
    // Returns the number of compares.
    public static int searchUnorder(int[] data1, int n1, int[] data2, int n2) {
        int compares;
        int i;
        compares = 0;
        for (i = 0; i < n2; i++)
            compares += searchSeq(data1, n1, data2[i]); // results of sequential search
        return compares; 
    }
    
    // searches for value in the array data.  Returns the number of compares
    // uses sequential search on unordered data.
    public static int searchSeq(int[] data, int n, int value) {
        int i;
        int counter;
        counter = 0;
        
        for(i = 0; i <= n; i++) {
            if(data[i] == value)
            counter++;
        }
        return counter;
    }
    // calls binary search for each number in second array looking for it
    // in first array.  Returns the number of compares.
    // first need to sort the data.
    public static int searchOrdered(int[] data1, int n1, int[] data2, int n2) {
        int compares;
        int i;
        compares = sortData(data1, n1);
        for (i=0; i < n2; i++)
            compares += 0; // results of a search needs changing
        return compares;
    }

    // binary search returning number of compares instead of location
    public static int searchBinaryNum(int[] data, int n, int value){
        boolean numFound;
        int low;
        int mid;
        int high;
        int counterCompared;
        low = 0;
        high = n-1;
        mid = (low + high)/2;  
        counterCompared = 0;
        numFound = false;
        
        while(!numFound && low <= high){
            mid = (low + high)/2;
            if(data[mid] == value){
               numFound = true;
               counterCompared++;
            }
            else if(value < data[mid]){
               high = mid - 1;
               counterCompared++;
            }
            else{low = mid + 1;
                 counterCompared++;
            }
        }
        if (numFound) return counterCompared;
        return counterCompared;
    } 
        
        
        
    // sorts data via Insertion sort.  Returns number of compares
    public static int sortData(int[] data, int size) {
        int temp;
        int j;
        int counter;  
        counter = 0;

        for (int i = 1; i < size; i++) {
            temp = data[i];
            j = i - 1;
            while (j >= 0 && data[j] > temp) {
                data[j + 1] = data[j];
                j = j - 1;
            }
            data[j + 1] = temp;
            counter++;
        }  
        return counter; 
    } 
        
    // generates n items in specified order. returns result in an array
    //      0   random order
    //      <0  relatively descending order
    //      -1  strictly descending order
    //      >0  relatively ascending order
    //      1   strictly ascending order
    public static int[] generateData(int n, int type) {
        if (type == 0)
            return generateRandom(n);
        else if (type < 0)
            return generateDesc(n, type);
        else return generateAsc(n, type);
    }
    
    // generates data in random order
    public static int[] generateRandom(int n)  {
        Random rand;
        int[] data;
        
        rand = new Random();
        data = new int[MAX];
        for (int i=0; i < n; i++)
            data[i] = rand.nextInt(n*2);
        return data;
    }
    
    // generates data in relativelty descending order
    // if -1, strictly descending order
    // returns data in an integer array
    public static int[]  generateDesc(int n, int type) {
        Random rand;
        int mult,j;
        int[] data;
                
        rand = new Random();
        data = new int[MAX];
        if (type == -1) mult = 0;
        else mult = 1;
        j = 0;
        for (int i=n*3; i>= 0; i -= 3) {
            data[j] =i+(rand.nextInt(10)-5)*mult;
            j++;
        }
        return data;
    }

    // generates data in relativelty ascending order
    // if -1, strictly ascending order
    // returns data in an integer array
    public static int[] generateAsc(int n, int type) {
        Random rand;
        int mult;
        int[] data;
        int j;
        
        rand = new Random();
        data = new int[MAX];
        if (type == 1) mult = 0;
        else mult = 1;
        j = 0;
        for (int i=0; i <= n*3; i += 3) {
            data[j] =i+(rand.nextInt(10)-5)*mult;
            j++;
        }
        return data;
    }
}